package com.otis.report.util;

import org.apache.log4j.Logger;

import util.RestConsumerAPI;

public class RESTServiceCaller {
	private static final Logger log = Logger.getLogger(RESTServiceCaller.class);
/*	public static void main(String args[]){
		String url = "https://1ccm-uat-p1.wellsfargo.net:8443/cdds/api/corpAction/bizDate/20170208";
		
		System.out.println("Resp is :"+callRest(url));
	}*/
	public static String callRest(String url){
		 log.info("Inside RESTServiceCaller::callRest() url:"+url);
		 RestConsumerAPI api = new  RestConsumerAPI();
		 String resp = api.getServiceData(url);
		 	/*	log.info("Inside RESTServiceCaller::callRest() Response from REST Call:"+resp);*/
		 //just write the response to log only if is reasonably smaller
		 if(resp.length()<100001){
			 log.info("Inside RESTServiceCaller::callRest() Response from REST Call:"+resp);
		 }else{
			 log.info("Inside RESTServiceCaller::callRest() Valid and successful response is obtained from REST call.....");
			 log.info("Inside RESTServiceCaller::callRest() Not writing the response to log file as the response contains more than 100000 chars...");
		 }
		 
		 log.info("Exiting from RESTServiceCaller::callRest()....... ");
		 return resp;
	}
}
