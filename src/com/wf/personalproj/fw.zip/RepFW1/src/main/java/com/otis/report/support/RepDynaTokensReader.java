package com.otis.report.support;

import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.otis.report.model.ReportFWData;
import com.otis.report.model.RptDynamicToken;

public class RepDynaTokensReader {
	private static final Logger log = Logger.getLogger(RepDynaTokensReader.class);
	public void setDynaTokensSep(String dynaTokensSep) {
		this.dynaTokensSep = dynaTokensSep;
	}
	public void setDynaTokenKeyValSep(String dynaTokenKeyValSep) {
		this.dynaTokenKeyValSep = dynaTokenKeyValSep;
	}
	private String dynaTokensSep;
	private String dynaTokenKeyValSep;
	public void updateRepFWDataWithDynaTokens(ReportFWData repFwData,String cmdLineDynaTokens){
		log.info("RepDynaTokensReader::updateRepFWDataWithDynaTokens() dynaTokensSep"+dynaTokensSep);
		log.info(" dynaTokenKeyValSep"+dynaTokenKeyValSep);
		log.info("repFwData.getRepDynTokenList().size()"+repFwData.getRepDynTokenList().size());
		for(RptDynamicToken rdt:repFwData.getRepDynTokenList()){
			repFwData.getDynamicTokenValsMap().put(rdt.getDynamicToken(), rdt.getDynamicTokenVal());
		}
		//Override dynamic tokens with command-line tokens
		if(StringUtils.isNotEmpty(cmdLineDynaTokens)){
			log.info("cmdLineDynaTokens are not empty, overriding with  cmdLineDynaTokens");
			StringTokenizer st = new StringTokenizer(cmdLineDynaTokens, dynaTokensSep);
			String strArr[] = null;
			while(st.hasMoreTokens()){
				strArr = st.nextToken().split(dynaTokenKeyValSep);
				if(strArr.length==2){
					repFwData.getDynamicTokenValsMap().put(strArr[0], strArr[1]);
				}	
			}
		}
		log.info("Exiting from updateRepFWDataWithDynaTokens()....");
	}
	
}
