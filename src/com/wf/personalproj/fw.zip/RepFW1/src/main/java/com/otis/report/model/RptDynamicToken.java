package com.otis.report.model;

public class RptDynamicToken {
	public String getReportId() {
		return reportId;
	}
	public String getDynamicToken() {
		return dynamicToken;
	}
	public String getDynamicTokenVal() {
		return dynamicTokenVal;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public void setDynamicToken(String dynamicToken) {
		this.dynamicToken = dynamicToken;
	}
	public void setDynamicTokenVal(String dynamicTokenVal) {
		this.dynamicTokenVal = dynamicTokenVal;
	}
	private int ID;
	private String reportId;
	private String dynamicToken;
	private String dynamicTokenVal;
}
