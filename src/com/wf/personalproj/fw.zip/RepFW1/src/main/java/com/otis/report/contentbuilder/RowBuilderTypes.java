package com.otis.report.contentbuilder;

public enum RowBuilderTypes {
	CSV,FLT,TXT
}
