package com.otis.report.util;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

import com.otis.report.support.SpecialValuesHandler;

public class ReportingFWUtil {
	public static boolean isNumeric(String strNum) {
	    boolean ret = true;
	    try {

	        Double.parseDouble(strNum);

	    }catch (NumberFormatException e) {
	        ret = false;
	    }
	    return ret;
	}
	
	public static boolean isValidSQL(String inStr){
		return (inStr.toUpperCase().contains("SELECT ")
				||inStr.toUpperCase().contains("EXEC ")
				||inStr.toUpperCase().contains("KEY:: "));
	}	
	
	public static boolean isStoredProc(String inStr){
		return (inStr.toUpperCase().contains("EXEC "));
	}	

	public static boolean hasDynamicToken(String inSql){
		return inSql.contains(getDynamicTokenIndr());
	}
	
	public static boolean isDynamicTokenSql(String inSql){
		return hasDynamicToken(inSql);
	}
	
	public static boolean isRestUrl(String inSql){
		return (StringUtils.contains(inSql, "http")||StringUtils.contains(inSql, "https") ||StringUtils.contains(inSql, "www"));
	}
	
	public static boolean hasSpecialValue(String inSql){
		return inSql.contains(getSpecialValIndr());
	}
	
	public static String getDynamicTokenIndr(){
		return "$$";
	}
	
	public static String getSpecialValIndr(){
		return "[#";
	}
	
	public static String getSpecialValCloseIndr(){
		return "]";
	}
	
	public static String getDynamicTokenCloseIndr(){
		return "%%";
	}

	public static String specialValValueNFormatSeperator(){
		return ":";
	}
	
	public static java.sql.Date addNDaysToToday(int n){
		if(n<1) n = n*-1;
		return new java.sql.Date(System.currentTimeMillis()+(1000*60*60*24*n));
	}
	
	public static java.util.Date addNDaysToCurrDate(int n){
		if(n<1) n = n*-1;
		return new java.sql.Date(System.currentTimeMillis()+(1000*60*60*24*n));
	}	
	
	public static String extractAndReplaceDynaTokens(String inStr,HashMap<String, String> dynaTokenValMap){
		String origStr = inStr;
		String dynaToken = "";
		while(inStr.contains("%%")&&inStr.contains("$$")){
			int doublePercentInd = inStr.indexOf("%%")+1;
			if(doublePercentInd==-1) break;
			dynaToken = StringUtils.substringBetween(inStr,"$$","%%");
			origStr = origStr.replace(dynaToken, dynaTokenValMap.get(dynaToken));
			inStr = inStr.substring(doublePercentInd+1);
		}	
		origStr = StringUtils.remove(origStr, "$$");
		origStr = StringUtils.remove(origStr, "%%");
		origStr = StringUtils.remove(origStr, "'");
		return origStr;
	}
	
	public static String extractAndReplaceSpecialValues(String inStr){
		String origStr = inStr;
		String specialVal = "";
		while(inStr.contains("[#")&&inStr.contains("]")){
			int openBrakIndex = inStr.indexOf("[#")+1;
			if(openBrakIndex==-1) break;
			specialVal = StringUtils.substringBetween(inStr,"[#","]");
			origStr = origStr.replace(specialVal, SpecialValuesHandler.handleSpecalizedValues(specialVal));
			inStr = inStr.substring(openBrakIndex+1);
		}	
		origStr = StringUtils.remove(origStr, "[#");
		origStr = StringUtils.remove(origStr, "]");
		origStr = StringUtils.remove(origStr, "'");
		return origStr;
	}
	/*public static String extractDynaToken(String inStr){
		return inStr.substring(inStr.lastIndexOf(getDynamicTokenIndr())+2,inStr.lastIndexOf(getDynamicTokenCloseIndr()));
	}	
	
	
	public static String replaceDynamicValNGetStr(String inStr,String dynaTokenVal){
		 String dynaToken = extractDynaToken(inStr);
		 String retVal = inStr.replaceAll("\\$", "");
		 retVal = retVal.replaceAll(getDynamicTokenCloseIndr(), "");

		 retVal = retVal.replaceAll(dynaToken, dynaTokenVal);
		 retVal = retVal.replaceAll("'", "");
		 
		 return retVal;
	}	*/
	
	public static String fillString(String fillerStr,int length){
		return StringUtils.repeat(fillerStr, length);
	}
	
	
	public static String getMessageFormatTokensStr(int upperbound,String tokenOpenIndr,String tokenCloseIndr){
		StringBuilder retVal = new StringBuilder("");
		for(int i=0;i<=upperbound;i++){
			retVal.append(tokenOpenIndr);
			retVal.append(i);
			retVal.append(tokenCloseIndr);
		}
		return retVal.toString();
	}
}
;