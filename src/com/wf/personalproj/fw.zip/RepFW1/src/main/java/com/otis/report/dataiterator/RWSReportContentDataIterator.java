package com.otis.report.dataiterator;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.otis.report.content.ReportContentData;

public class RWSReportContentDataIterator implements IReportContentDataIterator{

	private List<Map<String,String>> repContentAsListOfMaps = null;
	private Iterator<Map<String,String>> repContentDataIerator =null;
 	private static final Logger log = Logger.getLogger(RWSReportContentDataIterator.class);
	
	public RWSReportContentDataIterator(ReportContentData reportContentData) {
		log.info("Inside RWSReportContentDataIterator.......");
		
		this.repContentAsListOfMaps = (List<Map<String,String>>) reportContentData.getReportContent();	
		this.repContentDataIerator = repContentAsListOfMaps.iterator();
		
		log.info("Exiting from RWSReportContentDataIterator.......");
	}

	@Override
	public boolean hasNextRow() throws Exception{
		// TODO Auto-generated method stub
		return repContentDataIerator.hasNext();
	}

	@Override
	public Object fetchNextRowOfData() throws Exception{
		// TODO Auto-generated method stub
		return repContentDataIerator.next();
	}

}
