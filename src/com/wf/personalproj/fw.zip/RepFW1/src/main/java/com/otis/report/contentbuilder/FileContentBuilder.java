package com.otis.report.contentbuilder;

import java.nio.file.Path;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.otis.report.content.ReportContentData;
import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.model.ReportFWData;

public class FileContentBuilder {
	@Autowired
	private HeaderDtlsBuilder headerDtlsBuilder;
	@Autowired
	private DataRowsBuilderNWriter dataRowsBuilderNWriter;
	@Autowired
	private FooterDtlsBuilder footerDtlsBuilder;
	@Value("#{reportFWProp}")
	private Map<String,String> reportFWProp;
	private static final Logger log = Logger.getLogger(FileContentBuilder.class);
    public String getHeaderContent(ReportFWData reportFWData,GenericReportDAO genericDao)
    							throws Exception{
    	log.info("Inside FileContentBuilder::getHeaderContent()..");
    	return headerDtlsBuilder.buildHeaderContent(reportFWData,genericDao).toString();
    }
    
    public void buildNWriteDataRows(ReportFWData reportFWData,
			ReportContentData reportContentData,GenericReportDAO genericDao,Path outputFile) 
									throws Exception{
    	log.info("Inside FileContentBuilder::buildNWriteDataRows()..");
    	dataRowsBuilderNWriter.buildAndWriteDataRows(reportFWData, reportContentData, outputFile);
    }	
    
    public String getFooterContent(ReportFWData reportFWData,GenericReportDAO genericDao) 
    								throws Exception{
    	log.info("Inside FileContentBuilder::getFooterContent()..");
    	return footerDtlsBuilder.buildFooterContent( reportFWData, genericDao);
    }
}
