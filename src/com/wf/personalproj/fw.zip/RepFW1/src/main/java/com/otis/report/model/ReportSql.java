package com.otis.report.model;

public class ReportSql {
	
	private String reportid;
	

	private String headerValuesOrSqls;
	private String footerValuesOrSqls;
	private String dataValuesOrSqls;
	
	//this var is not mapped to DB and used internally
	
	
	public String getReportid() {
		return reportid;
	}
	public void setReportid(String reportid) {
		this.reportid = reportid;
	}

/*	@Override
	public String toString() {
		return "ReportSql [reportid=" + reportid + ", reportsql=" + reportsql
				+ "]";
	}*/
	
	public String getHeaderValuesOrSqls() {
		return headerValuesOrSqls;
	}
	public void setHeaderValuesOrSqls(String headerValuesOrSqls) {
		this.headerValuesOrSqls = headerValuesOrSqls;
	}
	public String getFooterValuesOrSqls() {
		return footerValuesOrSqls;
	}
	public void setFooterValuesOrSqls(String footerValuesOrSqls) {
		this.footerValuesOrSqls = footerValuesOrSqls;
	}
	public String getDataValuesOrSqls() {
		return dataValuesOrSqls;
	}
	public void setDataValuesOrSqls(String dataValuesOrSqls) {
		this.dataValuesOrSqls = dataValuesOrSqls;
	}
}
