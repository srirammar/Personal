package com.otis.report.contentbuilder;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.model.ReportFWData;
import com.otis.report.support.RepFormatProcessor;

public class FooterDtlsBuilder {

	@Autowired
	private RepFormatProcessor repFormatProcessor;
	private static final Logger log = Logger.getLogger(FooterDtlsBuilder.class);
	
	public String buildFooterContent(ReportFWData reportFWData
			,GenericReportDAO genericDao) throws Exception{
		
		log.info("Inside FooterDtlsBuilder::buildFooterContent()..");
		
		StringBuilder completeFooter = new StringBuilder("");
		String footerFormat = reportFWData.getRepFormat().getFooter();
		String sqlsOrDataValues = reportFWData.getRepSql().getFooterValuesOrSqls();
		repFormatProcessor.setRowCount(reportFWData.getRowCount());	

		String footerWithoutDisclaimerStr=  repFormatProcessor.processFormattedMsg(footerFormat,reportFWData,sqlsOrDataValues
				,"footer",genericDao).toString();
		//to be used for excel reporting
		log.info("FooterDtlsBuilder::buildFooterContent() footerWithoutDisclaimerStr:"+footerWithoutDisclaimerStr);
		completeFooter.append(footerWithoutDisclaimerStr);
		if(StringUtils.isNotEmpty(reportFWData.getRepFormat().getDisclaimer())
				&& !reportFWData.isExcelFile()){
			log.info("FooterDtlsBuilder::buildFooterContent() , disclaimer is not empty and non excel file scenario ");
			if(StringUtils.isNotEmpty(footerWithoutDisclaimerStr)){
				log.info("FooterDtlsBuilder::buildFooterContent() footerWithoutDisclaimerStr is non empty"
						+ " and appending new line... ");
				completeFooter.append(System.lineSeparator());
			}
			completeFooter.append("\""+reportFWData.getRepFormat().getDisclaimer()+"\"");
		}
		log.info("exiting from FooterDtlsBuilder::buildFooterContent()..");
		return completeFooter.toString();
	}
}
