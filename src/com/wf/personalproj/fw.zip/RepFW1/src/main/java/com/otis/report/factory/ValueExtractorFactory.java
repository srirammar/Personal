package com.otis.report.factory;

import com.otis.report.valueextractor.IValueExtractor;
import com.otis.report.valueextractor.RWSValueExtractor;
import com.otis.report.valueextractor.ResultSetValueExtractor;

public class ValueExtractorFactory {
	public static IValueExtractor createValueExtractor(String sourceOfData){
			return sourceOfData.equalsIgnoreCase("RWS")?new RWSValueExtractor()
					:new ResultSetValueExtractor();
	}
}
