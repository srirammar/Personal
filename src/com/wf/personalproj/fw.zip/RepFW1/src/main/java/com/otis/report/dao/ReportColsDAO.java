package com.otis.report.dao;

import java.util.List;

import com.otis.report.model.ReportCols;

public interface ReportColsDAO {

	public List<ReportCols> getReportCols();
	public List<ReportCols> getReportCols(String reportId);
}
