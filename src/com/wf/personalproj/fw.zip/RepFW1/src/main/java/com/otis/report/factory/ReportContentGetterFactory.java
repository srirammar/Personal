package com.otis.report.factory;

import org.springframework.beans.factory.annotation.Autowired;

import com.otis.report.contentgetter.DBReportContentGetter;
import com.otis.report.contentgetter.IReportContentGetter;
import com.otis.report.contentgetter.RWSReportContentGetter;

public class ReportContentGetterFactory {
	@Autowired
	private DBReportContentGetter dbRepContentGetter;
	@Autowired
	private RWSReportContentGetter rwsRepContentGetter;
	
	public  IReportContentGetter getReportContentGetter(String sourceOfData){
		return sourceOfData.equalsIgnoreCase("RWS")?rwsRepContentGetter:dbRepContentGetter;
	}
	
	public void setDbRepContentGetter(DBReportContentGetter dbRepContentGetter) {
		this.dbRepContentGetter = dbRepContentGetter;
	}
	public void setRwsRepContentGetter(RWSReportContentGetter rwsRepContentGetter) {
		this.rwsRepContentGetter = rwsRepContentGetter;
	}
}
