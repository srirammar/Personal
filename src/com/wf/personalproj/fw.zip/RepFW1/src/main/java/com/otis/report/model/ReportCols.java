package com.otis.report.model;

public class ReportCols {
	
	private String reportid;
	private String name;

	private String clazzType;
	private int width;
	private String alignment;
	private String format;
	public String getSourceDataFormat() {
		return sourceDataFormat;
	}
	public void setSourceDataFormat(String sourceDataFormat) {
		this.sourceDataFormat = sourceDataFormat;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	private String sourceDataFormat;
	private String defaultValue;
	
	public Integer getColIndex() {
		return colIndex;
	}
	public void setColIndex(Integer colIndex) {
		this.colIndex = colIndex;
	}

	private int colIndex;
	public String getReportid(){
		return reportid;
	}
	public void setReportid(String reportid) {
		this.reportid = reportid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClazzType() {
		return clazzType;
	}
	public void setClazzType(String clazzType) {
		this.clazzType = clazzType;
	}

	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public String getAlignment() {
		return alignment;
	}
	public void setAlignment(String alignment) {
		this.alignment = alignment;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	
	@Override
	public String toString() {
		return "ReportCols [reportid=" + reportid + ", name=" + name
				+ ", clazzType=" + clazzType + ", width=" + width + ", alignment=" + alignment + ", format=" + format + "]";
	}
	
	
	
}
