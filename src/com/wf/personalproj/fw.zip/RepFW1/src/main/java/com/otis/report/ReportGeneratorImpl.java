package com.otis.report;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.model.ReportFWData;
import com.otis.report.support.RepDynaTokensReader;
import com.otis.report.support.ReportFWDataFetcher;
import com.otis.report.support.ReportOPFileCreator;
import com.wfs.sbl.AvailabilityFeeds.DestinationType;
import com.wfs.sbl.AvailabilityFeeds.RptInstanceJSONReqGenerator;

@Component("ReportGenerator")
public class ReportGeneratorImpl implements ReportGenerator{
	private static final Logger log = Logger.getLogger(ReportGeneratorImpl.class);
	@Autowired
	private ReportFWDataFetcher repFwDataFetcher;
	@Autowired
	private ReportOPFileCreator repOPFileCreator;
	@Autowired
	private GenericReportDAO genericDao;
	@Autowired
	private RptInstanceJSONReqGenerator rptInstanceJsonReqGen;
	@Autowired
	private RepDynaTokensReader dynaTokensReader;
	@Value("#{reportFWProp}")
	private HashMap<String, String> reportFWProp;
	
	public boolean displayReport(String reportId,String cmdLineRptDynaTokens) throws Exception{
		log.info("Inside ReportGeneratorImpl::displayReport()..");
		boolean retVal = false;
		ReportFWData reportFWData = repFwDataFetcher.getReportFWData(reportId);

		dynaTokensReader.updateRepFWDataWithDynaTokens(reportFWData, cmdLineRptDynaTokens);
		log.info(reportFWData);
	    createReport(reportId,reportFWData);
		
		if(reportFWData.isOutputFileCreated()){
			log.info("Output file creation is successful..............");
			String email = reportFWData.getRepFormat().getEmail();
			if(StringUtils.isNotEmpty(email) && email.equalsIgnoreCase("Y")){
				 log.info("Trying to send email ......");
				 rptInstanceJsonReqGen.generateJSONRequestForReportInstance(reportId,DestinationType.EMAIL,reportFWData.getRepFormat());
			 }
			
			 String sftp = reportFWData.getRepFormat().getSftp();
			 if(StringUtils.isNotEmpty(sftp) && sftp.equalsIgnoreCase("Y")){
				 log.info("Trying to perform SFTP ......");
				 rptInstanceJsonReqGen.generateJSONRequestForReportInstance(reportId,DestinationType.SFTP,reportFWData.getRepFormat());
			 }			
			 log.info("Exiting with SUCCESS from ReportGeneratorImpl::displayReport()..");
			 retVal =  true;
		}else{
			 log.info("Exiting with ERROR from ReportGeneratorImpl::displayReport()..");
		}
		return retVal;
	}
	
	private void createReport(String reportId,ReportFWData reportFWData) throws Exception{
		repOPFileCreator.createOPFile(reportId,reportFWData,genericDao);
	}
}
