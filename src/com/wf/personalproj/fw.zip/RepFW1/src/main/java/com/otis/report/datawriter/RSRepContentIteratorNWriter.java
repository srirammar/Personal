package com.otis.report.datawriter;

import java.nio.file.Path;
import java.sql.ResultSet;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.otis.report.content.ReportContentData;
import com.otis.report.model.ReportFWData;

public class RSRepContentIteratorNWriter extends AbstractRepContentIteratorNWriter {

	private ResultSet repContentAsRS = null;
	private static final Logger log = Logger.getLogger(RSRepContentIteratorNWriter.class);
	
	@Override
	public void iterateDataNWriteRowsToFile(ReportContentData reportContentData,Properties reportFWProps
									,ReportFWData reportFWData,Path outputFile) throws Exception {
		log.info("Inside RSRepContentIteratorNWriter::iterateDataNWriteRowsToFile().......");
		log.info("Calling super.iterateDataNWriteRowsToFile() .....");
		
		this.repContentAsRS = (ResultSet) reportContentData.getReportContent();	

		super.iterateDataNWriteRowsToFile(reportContentData, reportFWProps, reportFWData, outputFile);
		log.info("Exiting from RSRepContentIteratorNWriter::iterateDataNWriteRowsToFile().......");
	}
	
	@Override
	public boolean hasNextRow() throws Exception{
		// TODO Auto-generated method stub
		return repContentAsRS.next();
	}

	@Override
	public Object fetchNextRowOfData() {
		// TODO Auto-generated method stub
		return repContentAsRS;
	}
}
