package com.otis.report.excel;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;

import com.otis.report.content.ReportContentData;
import com.otis.report.contentbuilder.FileContentBuilder;
import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.dataiterator.IReportContentDataIterator;
import com.otis.report.factory.ReportContentDataIteratorFactory;
import com.otis.report.factory.ValueExtractorFactory;
import com.otis.report.model.ReportCols;
import com.otis.report.model.ReportFWData;
import com.otis.report.valueextractor.IValueExtractor;


public class XlsxExcelReportGenerator {
	private static final Logger log = Logger.getLogger(XlsxExcelReportGenerator.class);

	@Autowired
	FileContentBuilder fileContentBuilder;


	private  CellStyle headerStyle;
	private  CellStyle footerStyle;
	
	private HashMap<String,CellStyle> repColName2CellStyleMap = new HashMap<String,CellStyle>();
	private static HashMap<String, HorizontalAlignment> ALIGN_MAP = new HashMap<String, HorizontalAlignment>();
	static{
		ALIGN_MAP.put("L", HorizontalAlignment.LEFT);
		ALIGN_MAP.put("R", HorizontalAlignment.RIGHT);
		ALIGN_MAP.put("C", HorizontalAlignment.CENTER);
	}
	public void generateExcelFile(String headerContent,ReportFWData reportFWData
					,ReportContentData reportContentData,File excelOPFile,GenericReportDAO genericDao
					,boolean isRepContentNull,boolean createEmptyFile) throws Exception{
			log.info("Inside XlsxExcelReportGenerator::generateExcelFile()..............");		
			
			int rowCount = -1;
			log.info("XlsxExcelReportGenerator::generateExcelFile() headerContent: "+headerContent);
			log.info("XlsxExcelReportGenerator::generateExcelFile() isRepContentNull: "+isRepContentNull);
			
			try (FileOutputStream fileOut = new FileOutputStream(excelOPFile);
					XSSFWorkbook wb = new XSSFWorkbook()) {
				initHeaderStyle(wb);
				XSSFSheet worksheet = wb.createSheet(excelOPFile.getName());
				
				XSSFRow row = null;
				XSSFCell cell = null;

				if (StringUtils.isNotEmpty(headerContent)) {
					log.info("XlsxExcelReportGenerator::generateExcelFile() adding headerContent...");
					row = worksheet.createRow(++rowCount);
					cell = row.createCell(0);
					cell.setCellStyle(headerStyle);
					cell.setCellValue(headerContent);
				}
				

				if(reportFWData.getHeaderFieldValStrList().size()>0){
					log.info("XlsxExcelReportGenerator::generateExcelFile() adding getHeaderFieldValStrList...");
					row = worksheet.createRow(++rowCount);
					Font headerFont = wb.createFont();
					headerFont.setBold(true);
					headerStyle.setFont(headerFont);
					for (int i = 0; i<reportFWData.getHeaderFieldValStrList().size(); i++) {
						cell = row.createCell(i);
						cell.setCellStyle(headerStyle);
						cell.setCellValue(reportFWData.getHeaderFieldValStrList().get(i));
					}
				}	
				int repConentDataRowCnt = 0; boolean createFile = false;
				String sourceOfData = reportFWData.getRepFormat().getDbName();
				log.info("XlsxExcelReportGenerator::generateExcelFile() sourceOfData"+sourceOfData);
				IReportContentDataIterator repContentIt = ReportContentDataIteratorFactory.createRepContentDataIterator(sourceOfData, reportContentData);

				IValueExtractor valueExtractor = ValueExtractorFactory.createValueExtractor(sourceOfData);
				if(!isRepContentNull){
					int i; String currColValue=""; ReportCols repCol = null;
					try{
						initRepColName2CellStyleMap(reportFWData.getReArrangedColList(),wb);
						while(repContentIt.hasNextRow()){
							++repConentDataRowCnt;
							row = worksheet.createRow(++rowCount);
							//initialize i to -1 for each row
							i = -1;	
							//process each data row
							for(int k=0;k<reportFWData.getReArrangedColList().size();k++){
								repCol = reportFWData.getReArrangedColList().get(k);
								currColValue = valueExtractor.extractValFromSourceUsingReportCol(reportContentData.getReportContent(), repCol,reportFWData);
				
								/*if(currColValue==null) currColValue ="";*/
								cell = row.createCell(++i);
								cell.setCellStyle(repColName2CellStyleMap.get(repCol.getName()));
								setValue2Cell(cell,currColValue,repCol);
							}	
						}
						log.info("XlsxExcelReportGenerator::generateExcelFile () Successfully finished INNER try with out any exception/error");
					}catch(Exception ex){
						log.error("XlsxExcelReportGenerator::generateExcelFile() Exception occurred while trying to iterate over the ResultSet....");
						log.error("XlsxExcelReportGenerator::generateExcelFile(), msg is logged from inner Exception block");
						if(!createEmptyFile){
							log.info("XlsxExcelReportGenerator::generateExcelFile() createEmptyFile is false setting createFile flag to false");
							createFile = false;							
						}
						ex.printStackTrace();
						throw ex;
					}
					if(repConentDataRowCnt<=0){
						log.info("XlsxExcelReportGenerator::generateExcelFile() repConentDataRowCnt<=0");
						if(!createEmptyFile){
							log.info("XlsxExcelReportGenerator::generateExcelFile() repConentDataRowCntM<=0 and createEmptyFile=false, setting createFile to true");
							createFile = false;							
						}
					}else{
						//if no exception and there are some rows then only proceedFurther == true
						log.info("XlsxExcelReportGenerator::generateExcelFile() repConentDataRowCnt>0, setting createFile to true");
						createFile = true;		
					}
				}
				//Auto size columns
				for(int colNum = 0; colNum<row.getLastCellNum();colNum++){   
				    wb.getSheetAt(0).autoSizeColumn(colNum);
				}
				if(createFile){
					log.info("XlsxExcelReportGenerator::generateExcelFile() Inside createFile true");
					String footerContent = fileContentBuilder.getFooterContent(reportFWData,genericDao); 
					initFooterStyle(wb);
					log.info("XlsxExcelReportGenerator::generateExcelFile() repConentDataRowCnt: "+repConentDataRowCnt);		
					reportFWData.setRowCount(repConentDataRowCnt);
					if (StringUtils.isNotEmpty(footerContent)) {
						log.info("XlsxExcelReportGenerator::generateExcelFile() adding footerContent...");
						row = worksheet.createRow(++rowCount);
						cell = row.createCell(0);
						cell.setCellStyle(footerStyle);
						cell.setCellValue(footerContent);
					}
					
					if (StringUtils.isNotEmpty(reportFWData.getRepFormat().getDisclaimer())) {
						log.info("XlsxExcelReportGenerator::generateExcelFile() adding Disclaimer...");
						row = worksheet.createRow(++rowCount);
						cell = row.createCell(0);
						cell.setCellStyle(footerStyle);
						cell.setCellValue(reportFWData.getRepFormat().getDisclaimer());
					}
					
					wb.write(fileOut);
					reportFWData.setOutputFileCreated(true);
					log.info("XlsxExcelReportGenerator::generateExcelFile() successfully wrote to outputFile....");	
				}else{
					log.info("XlsxExcelReportGenerator::generateExcelFile() Inside false");
					//if createFile == false then delete already created file
					log.info("XlsxExcelReportGenerator::generateExcelFile() deleting the empty report file as the createEmptyFile is set to false in rptReportFormat...");
					excelOPFile.deleteOnExit();
					log.error("Exiting with error from XlsxExcelReportGenerator::generateExcelFile() ....");
					log.error("Either the result set is null or no rows in the result set, could not create excel report....");
					throw new Exception("SEVERE: The data to populate in the report is empty and createEmptyFile is set to false, Report was not created..");
				}
				log.info("XlsxExcelReportGenerator::generateExcelFile () Successfully finished OUTER try with out any exception/error");
			} catch (Exception e) {
				log.error("XlsxExcelReportGenerator::generateExcelFile(), msg is logged from OUTER Exception block");
	    		log.info("Error from generateExcelFile () : Message : " + e.getMessage());
	    		e.printStackTrace();
				Throwable [] AllException = e.getSuppressed();
				for (Throwable ex : AllException ) {
					log.info("Error from XlsxExcelReportGenerator::generateExcelFile () : Message : " + ex.getMessage());
					log.info("Error from XlsxExcelReportGenerator::generateExcelFile () : StackTrace : " + ex.getStackTrace());
					log.info("Error from XlsxExcelReportGenerator::generateExcelFile () : StackTrace : " + ex);
				}
				throw e;
			}
			log.info("Exiting from XlsxExcelReportGenerator::generateExcelFile() ..... ");
		}
	
	private void initHeaderStyle(XSSFWorkbook wb){

		headerStyle = wb.createCellStyle();

		headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headerStyle.setBorderBottom(BorderStyle.MEDIUM);
		headerStyle.setBorderTop(BorderStyle.MEDIUM);
		headerStyle.setBorderRight(BorderStyle.MEDIUM);
		headerStyle.setBorderLeft(BorderStyle.MEDIUM);
	}
	
	private void initRepColName2CellStyleMap(List<ReportCols> repColsList,XSSFWorkbook wb){
		for(ReportCols repCol:repColsList){
			repColName2CellStyleMap.put(repCol.getName(),createCellStyle(wb,repCol));
		}
	}
	private void initFooterStyle(XSSFWorkbook wb){
		footerStyle = wb.createCellStyle();

		footerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		footerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		footerStyle.setBorderBottom(BorderStyle.THIN);
		footerStyle.setBorderTop(BorderStyle.THIN);
		footerStyle.setBorderRight(BorderStyle.THIN);
		footerStyle.setBorderLeft(BorderStyle.THIN);
	}
	private CellStyle createCellStyle(XSSFWorkbook wb,ReportCols repCol){
		CellStyle cStyle = wb.createCellStyle();
		XSSFDataFormat hdf = wb.createDataFormat();
		cStyle.setBorderBottom(BorderStyle.THIN);
		cStyle.setBorderTop(BorderStyle.THIN);
		cStyle.setBorderRight(BorderStyle.THIN);
		cStyle.setBorderLeft(BorderStyle.THIN);

		String keyChar = repCol.getAlignment().substring(0,1).toUpperCase();
		HorizontalAlignment alignment = (ALIGN_MAP.get(keyChar)!=null)?ALIGN_MAP.get(keyChar):HorizontalAlignment.GENERAL;
		if(!repCol.getClazzType().equalsIgnoreCase("string")){
			cStyle.setDataFormat(hdf.getFormat(repCol.getFormat()));
		}
		cStyle.setAlignment(alignment);
		cStyle.setVerticalAlignment(VerticalAlignment.JUSTIFY);

		
		return cStyle;
	}
	
	private void setValue2Cell( XSSFCell cell,String currCellVal,ReportCols repCol) throws Exception{

		String dataType = repCol.getClazzType().toLowerCase();
		if(dataType.equals("int")||dataType.equals("double")
				||dataType.equals("float")||dataType.equals("currency")){
			double dVal = 0.00;
			if(currCellVal==null){
				cell.setCellType(CellType.BLANK);
				return;
			}
			currCellVal = StringUtils.remove(currCellVal, ",");
			currCellVal = StringUtils.remove(currCellVal, "$");

			try{
				dVal = Double.parseDouble(currCellVal);
			}catch(Exception ex){
				dVal = 0.00;
			}
			cell.setCellValue(dVal);
			cell.setCellType(CellType.NUMERIC);
		}else if(dataType.equals("date")||dataType.equals("timestamp")){
				Date date = null;
				try{
					date = new SimpleDateFormat(repCol.getFormat()).parse(currCellVal);
				}catch(Exception ex){
					date = null;
				}
				if(date==null){
					cell.setCellType(CellType.BLANK);
					return;
				}
				cell.setCellValue(date);
				cell.setCellType(CellType.NUMERIC);
		}else{
			 cell.setCellValue(currCellVal);
			 cell.setCellType(CellType.STRING);
		}		
	}
	public static boolean isNumeric(String str) {
		if(StringUtils.isNotEmpty(str)) return false;
		try {
			Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false;
		} catch (Exception e) {
			return false;
		}
		return true;
	}
}
