package com.otis.report.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.otis.report.dao.ReportColsDAO;
import com.otis.report.model.ReportCols;

@Component("ReportColsDAOImpl")
public class ReportColsDAOImpl implements ReportColsDAO {	
	@Autowired
	private RowMapper<ReportCols> reportColsMapper;

	
	@Autowired
	private SimpleJdbcCall sblDataSource;
	
	private String repColsSql;
	private static final Logger log = Logger.getLogger(ReportColsDAOImpl.class);
	public void setRepColsSql(String repColsSql) {
		this.repColsSql = repColsSql;
	}

	public void setRepFormatSql(String repColsSql) {
		this.repColsSql = repColsSql;
	}

	public List<ReportCols> getReportCols() {
		 return  (List<ReportCols>) sblDataSource.getJdbcTemplate().query(this.repColsSql,reportColsMapper);
	}
	
	public List<ReportCols> getReportCols(String reportId) {
		 log.info("Inside ReportColsDAOImpl:: getReportCols(reportId) ");
		List<ReportCols> filteredList = new ArrayList<ReportCols>();
		for(ReportCols rc:getReportCols()){
			if(rc.getReportid().equalsIgnoreCase(reportId)){
				filteredList.add(rc);
			}
		}
		log.info("Exiting from ReportColsDAOImpl:: getReportCols(reportId) filtered rep col list size "+filteredList.size());
		return filteredList;
	}
}
