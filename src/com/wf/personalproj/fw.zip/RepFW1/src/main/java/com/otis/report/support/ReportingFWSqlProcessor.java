package com.otis.report.support;

import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.model.ReportFWData;
import com.otis.report.util.ReportingFWUtil;

import util.PropertiesLoader;
public class ReportingFWSqlProcessor {
	private static Properties reportFWProps;
	static{
		reportFWProps = PropertiesLoader.loadProperties("ReportingFW.properties");
	}
	private static String dynamicSqlIndr =ReportingFWUtil.getDynamicTokenIndr();
	private static final Logger log = Logger.getLogger(ReportingFWSqlProcessor.class);
	
	//Following Code added for support of dynamic token sql
	
		//The reporting f/w sql can be normal sql or a sql with dynamic tokens like $$V1,$$V2..etc
		//The token values will either be supplied from command-line args (as $$V1=1234,..) or configured/provided  
		//from table rptDynamic_Tokens. If a value for eg $$V1 is configured in both rptDynamic_Tokens table
		//and supplied from command line arg, the value from command line arg take precedence
		
		//The value configured in rptDynamic_Tokens can inturn be a sql or storedproc/func call or again another 
		//dynamic sql or stored proc call	
		

		public static String processReportingFWSql(String inSql,GenericReportDAO gDao,
				ReportFWData reportFWData) throws Exception{
			log.info("ReportingFWSqlProcessor::processReportingFWSql() inSql"+inSql);
			
			inSql = inSql.trim();
			
			if(inSql.toUpperCase().contains("KEY::")){
				log.info("ReportingFWSqlProcessor::processReportingFWSql() fetching actual sql from prop file");
				inSql = reportFWProps.getProperty(StringUtils.substringAfter(inSql, "KEY::"));
				log.info("ReportingFWSqlProcessor::processReportingFWSql() fetching actual sql from prop file");
			}
			if(StringUtils.isEmpty(inSql)){
				throw new Exception("SEVERE:No Sql is configured in DataValuesOrSqls field of ReportSql table...");
			}
			
			if(!isDynamicTokenSql(inSql)){
				log.info("ReportingFWSqlProcessor::processReportingFWSql() inSql does not contain dynamic tokens...");
				return inSql;
			}
			String[] dynamicTokens = getDynamicTokens(inSql);
			log.info("ReportingFWSqlProcessor::processReportingFWSql() dynamicTokens.length:"+dynamicTokens.length);
			inSql = StringUtils.remove(inSql, dynamicSqlIndr);
			
			for(String currDToken:dynamicTokens){
				String dynamicTokenProcessedVal = null;
				if(reportFWData.getdTokenEvalMap().containsKey(currDToken)){
					dynamicTokenProcessedVal = reportFWData.getdTokenEvalMap().get(currDToken);
				}else{
					String dynTokenValFromMap = reportFWData.getDynamicTokenValsMap().get(currDToken);
					if(dynTokenValFromMap==null){
						throw new Exception("Either one of the dynamic value is not configured in table nor supplied from outside");
					}
					dynamicTokenProcessedVal =  processDynamicTokenVal(currDToken,dynTokenValFromMap, gDao,reportFWData);
					inSql = StringUtils.replace(inSql, currDToken, dynamicTokenProcessedVal);					
				}
			}
			log.info("ReportingFWSqlProcessor::processReportingFWSql() inSql after processing dynamic tokens:"+inSql);
			return inSql;
		}
		
		private static String processDynamicTokenVal(String currDToken,String dTokenValue,GenericReportDAO gDao,
				ReportFWData reportFWData) throws Exception{
			log.info("ReportingFWSqlProcessor::processDynamicTokenVal() currDToken: "+currDToken);
			dTokenValue = dTokenValue.trim();
			log.info("ReportingFWSqlProcessor::processDynamicTokenVal() dTokenValue: "+dTokenValue);
			String retVal = null;
			if(!ReportingFWUtil.isValidSQL(dTokenValue)){
				log.info("ReportingFWSqlProcessor::processDynamicTokenVal() dTokenValue is not sql, returning dTokenValue");
				retVal = dTokenValue;
			}else{
				log.info("ReportingFWSqlProcessor::processDynamicTokenVal() calling scrutinizeSqlDynamicToken with dTokenValue: "+dTokenValue);
				retVal = scrutinizeSqlDynamicToken(dTokenValue,gDao,reportFWData);
			}
			if(!reportFWData.getdTokenEvalMap().containsKey(currDToken)){
				log.info("ReportingFWSqlProcessor::processDynamicTokenVal() getdTokenEvalMap does not contain key "+currDToken);
				log.info("ReportingFWSqlProcessor::processDynamicTokenVal() putting "+retVal+" in getdTokenEvalMap for key "+currDToken);
				reportFWData.getdTokenEvalMap().put(currDToken, retVal);
			}
			log.info("ReportingFWSqlProcessor returing "+retVal+" from processDynamicTokenVal()");
			return retVal;
		}
		
		private static String scrutinizeSqlDynamicToken(String dTokenSql,GenericReportDAO gDao
				,ReportFWData reportFWData) throws Exception{
			//Must have been normal sql
			log.info("Inside ReportingFWSqlProcessor::scrutinizeSqlDynamicToken() dTokenSql:"+dTokenSql);
			
			return gDao.executeSQLAndFetchResult(reportFWData.getRepFormat().getDbName(),!isDynamicTokenSql(dTokenSql)?dTokenSql:
				processReportingFWSql(dTokenSql,gDao, reportFWData),true);
		}
		private static String[] getDynamicTokens(String inSqlOrUrl){
			log.info("Inside ReportingFWSqlProcessor::getDynamicTokens() ");
			String origInSqlOrUrl = new String(inSqlOrUrl);
			String dynamicTokens[] = new String[StringUtils.countMatches(inSqlOrUrl,dynamicSqlIndr)];
			int cnt = -1;
			while(inSqlOrUrl.contains(dynamicSqlIndr)||inSqlOrUrl.length()>0){
				char indexOfChar = getIndexOfChar(origInSqlOrUrl,inSqlOrUrl);
				int dollarInd = inSqlOrUrl.indexOf(dynamicSqlIndr.charAt(0));
				if(dollarInd==-1) break;
				if(inSqlOrUrl.charAt(dollarInd+1)!=dynamicSqlIndr.charAt(0)){
					inSqlOrUrl = inSqlOrUrl.substring(dollarInd+1);
					continue;
				}
				int indexOfCharIndInTempStr = inSqlOrUrl.substring(dollarInd+2).indexOf(indexOfChar);
			
				int dynaTokenSubStrEndInd = (dollarInd+2+indexOfCharIndInTempStr);
				
				dynamicTokens[++cnt] =  (indexOfCharIndInTempStr==-1)?inSqlOrUrl.substring(dollarInd+2)
								:inSqlOrUrl.substring(dollarInd+2,dynaTokenSubStrEndInd);
				dynamicTokens[cnt] = dynamicTokens[cnt].replaceAll("[^a-zA-Z0-9]", "");
			
				if(indexOfCharIndInTempStr==-1){
					break;
				}else{
					inSqlOrUrl = inSqlOrUrl.substring(dynaTokenSubStrEndInd+1);
				}
			}
			
			log.info("Exiting from  ReportingFWSqlProcessor::getDynamicTokens() dynmaicTokens.length: "+dynamicTokens.length);
			return dynamicTokens;
		}
		
		private static char getIndexOfChar(String origInSqlOrUrl,String inSqlOrUrl){
			char retVal = ' ';
			if(ReportingFWUtil.isRestUrl(origInSqlOrUrl)){
				if(StringUtils.contains(inSqlOrUrl, "?")){
					retVal = (StringUtils.substring(inSqlOrUrl, 0, inSqlOrUrl.indexOf('?')-1).contains("$$"))?'?':'&';
				}else{
					if(StringUtils.contains(inSqlOrUrl, "&")){
						retVal = '&';
					}else{
						if(StringUtils.contains(inSqlOrUrl, "/$$")){
							retVal = '/';
						}
					}
				}
			}
			else if(ReportingFWUtil.isStoredProc(origInSqlOrUrl)){
				retVal = ',';
			}else{
				retVal = ' ';
			}
			
			return retVal;
		}
		private static boolean isDynamicTokenSql(String inSql){
			return inSql.contains(dynamicSqlIndr);
		}		
	}
