package com.otis.report.support;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.ResultSet;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.otis.report.content.ReportContentData;
import com.otis.report.contentbuilder.FileContentBuilder;
import com.otis.report.contentgetter.IReportContentGetter;
import com.otis.report.factory.ReportContentGetterFactory;
import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.excel.ExcelReportGenerator;
import com.otis.report.excel.XlsxExcelReportGenerator;
import com.otis.report.exception.NoDataRowsExistException;
import com.otis.report.model.ReportFWData;
import com.otis.report.util.ReportingFWUtil;

public class ReportOPFileCreator {
	private static final Logger log = Logger.getLogger(ReportOPFileCreator.class);
	@Autowired
	private FileContentBuilder fileContentBuilder;
	@Autowired
	private ExcelReportGenerator excelGenerator;
	@Autowired
	private XlsxExcelReportGenerator xlsxGenerator;
	@Autowired
	private ReportContentGetterFactory repContentGetterFactory;
	private String invalidQueryOrDbMsg;

	private String  invalidRestUrlConnSetup;
	private String  sourceOfDataRestIndr;

	public void createOPFile(String reportId,ReportFWData reportFWData,GenericReportDAO genericDao) 
			throws Exception{
		log.info("Inside ReportOPFileCreator::createOPFile()..");

		boolean createEmptyFile = false;
		ReportContentData reportContentData = null;
		File repFile = null;
	
		try {
			String opFileDir =System.getProperty("OPFILEDIR");
			log.info("ReportOPFileCreator::createOPFile() outputDir from System property :"+opFileDir);
			String opFileLocation =null;
			//Directory location
			if(StringUtils.isEmpty(opFileDir)){
				log.info("ReportOPFileCreator::createOPFile() outputDir from System property is empty"
						+ ", obtaining it from repFormat table");
				 opFileDir = reportFWData.getRepFormat().getOutputDir();
			}
			log.info("ReportOPFileCreator::createOPFile() opFileDir:"+opFileDir);
			opFileDir = checkNCreateDir(opFileDir);
			log.info("ReportOPFileCreator::createOPFile() opFileDir after calling checkNCreateDir():"
						+opFileDir);
			
			//fileName Location			
			String opFileName = reportFWData.getRepFormat().getOutputFile();
			log.info("ReportOPFileCreator::createOPFile() opFileName "+opFileName);
			if(StringUtils.isEmpty(opFileName) || StringUtils.isEmpty(opFileDir)){
				throw new Exception("Please configure output file name");
			}
			
			opFileLocation = opFileDir+opFileName;
			
			log.info("ReportOPFileCreator::createOPFile() opFileLocation "+opFileLocation);
			
			if(ReportingFWUtil.hasSpecialValue(opFileLocation)){
				log.info("ReportOPFileCreator::createOPFile() : opFileLocation has special values ");
				opFileLocation = ReportingFWUtil.extractAndReplaceSpecialValues(opFileLocation);
				log.info("ReportOPFileCreator::createOPFile() opFileLocation after replacing special values:"+opFileLocation);
			}
			String headerContent = fileContentBuilder.getHeaderContent(reportFWData, genericDao);
			
			log.info("ReportOPFileCreator::createOPFile() headerContent:"+headerContent);
			
			if(StringUtils.isEmpty(reportFWData.getRepSql().getDataValuesOrSqls())){
				throw new Exception("SEVERE:No Sql is configured in DataValuesOrSqls field of ReportSql table...");
			}
			String processedDataValuesSql =  ReportingFWSqlProcessor.processReportingFWSql(
					reportFWData.getRepSql().getDataValuesOrSqls(),genericDao,reportFWData);
			log.info("ReportOPFileCreator::createOPFile() processedDataValuesSql :"+processedDataValuesSql);
			
			if(ReportingFWUtil.hasDynamicToken(opFileLocation)){
				log.info("ReportOPFileCreator::createOPFile() : opFileLocation has dynamic tokens");
				opFileLocation = ReportingFWUtil.extractAndReplaceDynaTokens(opFileLocation, reportFWData.getdTokenEvalMap());
				log.info("ReportOPFileCreator::createOPFile() opFileLocation after replacing dynaTokens:"+opFileLocation);
			}
			String sourceOfData = reportFWData.getRepFormat().getDbName();
			log.info("ReportOPFileCreator::createOPFile() sourceOfData : "+sourceOfData);
			reportFWData.getRepFormat().setReplacedFileName(opFileLocation);
			IReportContentGetter repContentGetter = repContentGetterFactory.getReportContentGetter(sourceOfData);
			reportContentData = repContentGetter.fetchReportContent(processedDataValuesSql, sourceOfData);
			/*resultSet = genericDao.getResultSet(reportFWData.getRepFormat().getDbName()
					,processedDataValuesSql);*/
			
			log.info("ReportOPFileCreator::createOPFile() obtained ReportContent Data :"+reportContentData.getReportContent());
			
			String createEmptyFileStr = reportFWData.getRepFormat().getCreateEmptyFile();
			log.info("ReportOPFileCreator::createOPFile() createEmptyFileStr : "+createEmptyFileStr);
			
			if(StringUtils.isNotEmpty(createEmptyFileStr)  && createEmptyFileStr.trim().equalsIgnoreCase("Y")){
				createEmptyFile = true;
			}
			
			log.info("ReportOPFileCreator::createOPFile() createEmptyFile flag : "+createEmptyFile);
			
			if(!generateFile(reportFWData,reportContentData,sourceOfData)){
				throw new Exception("SEVERE:There is no data availale in the table(s) to create report. Report was not generated");
			}else{
				log.info("ReportOPFileCreator::createOPFile() generateFile() true case... ");
				if(reportContentData.isReportContentDataNull()){
					log.info("ReportOPFileCreator::createOPFile(): createEmptyFile flag is set to true in the rptReportFormat, generating report file"
							+ "with header, footer and no data rows....");
					log.info("ReportOPFileCreator::createOPFile():setting createEmptyFile flag to true..");
				}
			}
			repFile = new File(opFileLocation);
			Path repFilePath = repFile.toPath();
			log.info("ReportOPFileCreator::createOPFile() obtained repFile and repFilePath objects.... ");
			if(repFile.exists()){
				log.info("ReportOPFileCreator::createOPFile(): report file already exists and trying to delete ..");
				if(repFile.delete()){
					log.info("The O/P file was already existing. Successfully deleted existing file......");
				}else{
					log.info("The O/P file was already existing but deletion of existing file has failed.");
				}
			}
			
			if(repFile.createNewFile()){
				log.info("The O/P file was not existing. created new O/P file......");
			}else{
				log.info("The O/P file was not existing. Problem with creating new O/P file.....");
				throw new Exception("SEVERE:Unable to create O/P file for writing :"+ opFileLocation);
			}
			
		
			boolean deleteCreatedRep = false;
			if(!reportFWData.isExcelFile()){
					log.info("ReportOPFileCreator::createOPFile(): Inside non Excel File path ...");
					Files.write(repFilePath,headerContent.getBytes(),StandardOpenOption.APPEND);
					log.info("ReportOPFileCreator::createOPFile():,successfully wrote headerContent");
					
					if(!reportContentData.isReportContentDataNull()){
						try{
							fileContentBuilder.buildNWriteDataRows(reportFWData, reportContentData, genericDao,repFilePath);
						}catch(NoDataRowsExistException nodrex){
							log.info("ReportOPFileCreator::createOPFile():No data rows exists in the resultset to create report,setting deleteCreatedRep to true ");
							if(!createEmptyFile){
								deleteCreatedRep = true;								
							}
						 }
					}
					if(deleteCreatedRep){
						log.info("deleteCreatedRep flag is true, so deleting the already created report file......");
						repFile.deleteOnExit();
					}else{
						String footerContent = fileContentBuilder.getFooterContent(reportFWData,genericDao); 
						log.info("ReportOPFileCreator::createOPFile() footerContent:"+footerContent);
						Files.write(repFilePath,footerContent.getBytes(),StandardOpenOption.APPEND);
						reportFWData.setOutputFileCreated(true);
						log.info("ReportOPFileCreator::createOPFile():,successfully wrote footerContent");
						log.info("Successfully created report output file......");
						log.info("Successfully exiting from ReportOPFileCreator::createOPFile()..");
					}
			}else{
				log.info("ReportOPFileCreator::createOPFile(): Inside Excel File path ...");
				if(reportFWData.isXlsxFile()){
					log.info("ReportOPFileCreator::createOPFile(): Inside Xlsx file path, Calling XlsxExcelReportGenerator.....");
					xlsxGenerator.generateExcelFile(headerContent,reportFWData,reportContentData,repFile,genericDao
							,reportContentData.isReportContentDataNull(),createEmptyFile);
				}else{
					log.info("ReportOPFileCreator::createOPFile(): Inside normal excel file path, Calling normal ExcelReportGenerator.....");
					excelGenerator.generateExcelFile(headerContent,reportFWData,reportContentData,repFile,genericDao
							,reportContentData.isReportContentDataNull(),createEmptyFile);
				}

			}
	    } catch(Exception ex){
	    	 log.error("SEVERE:Could not generate report. Exception occurred while trying to fetch data rows from result set.");
	    	 log.info("Exiting with ERROR from ReportOPFileCreator::createOPFile()..");
			 ex.printStackTrace();
			 throw ex;
		}finally{
			log.info("ReportOPFileCreator::createOPFile() Inside finally closing resources .... ");
			if(reportContentData.getReportContent() instanceof ResultSet){
				ResultSet resultSet = (ResultSet)reportContentData.getReportContent();
				if(resultSet!=null){try{resultSet.close();}catch(Exception ex){}}
			}
			
 			genericDao.closeStmtAndConn();
 			log.info("ReportOPFileCreator::createOPFile() exiting finally after closing resources .... ");
		}
	}
	
	private boolean generateFile(ReportFWData reportFWData,ReportContentData repContentData
							,String sourceOfData) {
		   log.info("Inside ReportOPFileCreator::generateFile() ");
		   boolean retVal = false;
		   String createEmptyFile = reportFWData.getRepFormat().getCreateEmptyFile();
		   
		   
		   if(StringUtils.isNotEmpty(createEmptyFile)  && createEmptyFile.trim().equalsIgnoreCase("Y")){
			   log.info("ReportOPFileCreator::generateFile(),createEmptyFile is configured to Y"
			   		+ ",returning true from generateFile()"); 
			   retVal = true;
		   }else{
			   if(repContentData.isReportContentDataNull()){
				   String errorMsg = (sourceOfData.equalsIgnoreCase(sourceOfDataRestIndr))?
						    "The JSON ouput string from REST service is null. There must be some error in REST url configuration or REST service provider"
						   :"The result set is null. There must be some error in query or DB connection setup";
					log.error(errorMsg);
					String msgToLog = (sourceOfData.equalsIgnoreCase(sourceOfDataRestIndr))?invalidRestUrlConnSetup:invalidQueryOrDbMsg;
					log.error(msgToLog);
				}
			   retVal =  repContentData.isReportContentDataNotNull();
		   }
		   log.info("ReportOPFileCreator::generateFile() retVal is:" +retVal);
		   return retVal;
	 }
	
/*	private int getRowCount(ReportFWData reportFWData,ResultSet rs) {
		log.info("Inside ReportOPFileCreator::getRowCount() ");
		int rowCount = 0;
		if(rs==null){
			log.error("The result set is null. There must be some error in query or DB connection setup");
			log.error(invalidQueryOrDbMsg);
			return 0;
		}
		try{
			if (rs.last()) {
				log.info("ReportOPFileCreator::getRowCount(),successfully done rs.last().. ");
				rowCount = rs.getRow();
				reportFWData.setRowCount(rowCount);
				rs.beforeFirst(); // not rs.first() because the rs.next() below will move on, missing the first element
				log.info("ReportOPFileCreator::getRowCount(),successfully done rs.beforeFirst().. ");
			}
		}catch(Exception ex){
			log.info("Exception occurred inside getRowCount(ResultSet rs), returing rowCount as zero.....");
		}
		log.info("ReportOPFileCreator::getRowCount() returing rowCount: "+rowCount);
		return rowCount;
	}
*/
	public void setInvalidQueryOrDbMsg(String invalidQueryOrDbMsg) {
		this.invalidQueryOrDbMsg = invalidQueryOrDbMsg;
	}
	
	public void setInvalidRestUrlConnSetup(String invalidRestUrlConnSetup) {
		this.invalidRestUrlConnSetup = invalidRestUrlConnSetup;
	}
	public void setSourceOfDataRestIndr(String sourceOfDataRestIndr) {
		this.sourceOfDataRestIndr = sourceOfDataRestIndr;
	}
	private String checkNCreateDir(String inDir) throws Exception{
		log.info("ReportOPFileCreator::checkNCreateDir() inDir:"+inDir);
		
		inDir = inDir.replaceAll("[\\\\]", "/");
		  if(!inDir.endsWith("/")){
			  inDir += "/";
		  }
		  File dirFile = new File(inDir);
		  if(!dirFile.exists()){
			  log.info("The directory: "+inDir+" :does not exist, trying to create O/P directory");
			  if(dirFile.mkdirs()){
				  log.info("The O/P directory was not existing. created the O/P directory......");
			  }
		  }
		  log.info("ReportOPFileCreator::checkNCreateDir() inDir before exiting:"+inDir);
		  return inDir;
	}
}
