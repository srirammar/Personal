package com.otis.report.datawriter;

import java.nio.file.Path;
import java.util.Properties;

import com.otis.report.content.ReportContentData;
import com.otis.report.dataiterator.IReportContentDataIterator;
import com.otis.report.model.ReportFWData;

public interface IRepContentIteratorNWriter extends IReportContentDataIterator {
	public void iterateDataNWriteRowsToFile(ReportContentData reportContentData,Properties reportFWProps
							,ReportFWData reportFWData,Path outputFile) throws Exception;
}
