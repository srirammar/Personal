package com.otis.report.dataiterator;

public interface IReportContentDataIterator {
	public abstract boolean hasNextRow() throws Exception;
	public abstract Object fetchNextRowOfData() throws Exception; 
}
