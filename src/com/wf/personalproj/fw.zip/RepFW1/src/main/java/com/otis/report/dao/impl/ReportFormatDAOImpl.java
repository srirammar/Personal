package com.otis.report.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.otis.report.dao.ReportFormatDAO;
import com.otis.report.model.ReportFormat;

@Component("ReportFormatDAOImpl")
public class ReportFormatDAOImpl implements ReportFormatDAO {
	@Autowired
	RowMapper<ReportFormat> rpFormatMapper;
	
	@Autowired
	private SimpleJdbcCall sblDataSource;
	private String repFormatSql;
	
	public void setRepFormatSql(String repFormatSql) {
		this.repFormatSql = repFormatSql;
	}

	public List<ReportFormat> getReportFormat() {
		// TODO Auto-generated method stub
		 return  (List<ReportFormat>) sblDataSource.getJdbcTemplate().query(repFormatSql,rpFormatMapper);
	}
	public ReportFormat getReportFormat(String reportId) {
		ReportFormat retValue =null;
		for(ReportFormat rf:getReportFormat()){
			if(rf.getReportid().equalsIgnoreCase(reportId)){
				retValue = rf; break;
			}
		}
		return retValue;
	}

}
