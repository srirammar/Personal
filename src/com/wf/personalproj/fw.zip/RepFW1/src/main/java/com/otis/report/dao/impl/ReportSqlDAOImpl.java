package com.otis.report.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.otis.report.dao.ReportSqlDAO;
import com.otis.report.model.ReportSql;

@Component("ReportSqlDAOImpl")
public class ReportSqlDAOImpl implements ReportSqlDAO {
	@Autowired
	private RowMapper<ReportSql> reportSqlMapper;
	@Autowired
	private SimpleJdbcCall sblDataSource;
	private String repSql;
	public void setRepSql(String repSql) {
		this.repSql = repSql;
	}

	public List<ReportSql> getReportSql() {
		// TODO Auto-generated method stub
		 return  (List<ReportSql>) sblDataSource.getJdbcTemplate().query(repSql,reportSqlMapper);
	}
	public ReportSql getReportSql(String reportId) {
		ReportSql retVal = null;
		for(ReportSql rs:getReportSql()){
			if(rs.getReportid().equalsIgnoreCase(reportId)){
				retVal = rs;break;
			}
		}
		return retVal;
	}

}
