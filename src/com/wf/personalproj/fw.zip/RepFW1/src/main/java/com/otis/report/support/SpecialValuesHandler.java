package com.otis.report.support;

import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.otis.report.util.ReportingFWUtil;

public class SpecialValuesHandler {
	private static final Logger log = Logger.getLogger(SpecialValuesHandler.class);
	public static String handleSpecalizedValues(String inSpecialVal){
		log.info("SpecialValuesHandler::handleSpecalizedValues() inSpecialVal:"+inSpecialVal);
		   String retVal = "";
			if(inSpecialVal.contains(":")){
				String specialVal = inSpecialVal.substring(0,StringUtils.indexOf(inSpecialVal,":"));
				log.info("SpecialValuesHandler::handleSpecalizedValues() specialVal:"+specialVal);
				String specialValFormat = inSpecialVal.substring(StringUtils.indexOf(inSpecialVal,":")+1);
				log.info("SpecialValuesHandler::handleSpecalizedValues() specialValFormat:"+specialValFormat);
				if(specialVal.toLowerCase().startsWith("today")){
					SimpleDateFormat sdf = new SimpleDateFormat(specialValFormat);
					int val = 0;
					if(specialVal.contains("+")||specialVal.contains("-")){
						val = new Integer(specialVal.substring(6));
					}
					retVal = sdf.format(ReportingFWUtil.addNDaysToCurrDate(val));
				}else if(specialVal.toLowerCase().startsWith("filler(")){
					String fillerStr = specialVal.substring(specialVal.indexOf("(")+1,specialVal.lastIndexOf(")"));
					//String[] fillerFields = fillerFieldInfo.split(":");
					retVal = ReportingFWUtil.fillString(fillerStr, Integer.parseInt(specialValFormat)); 
				}
			}
			log.info("Exiting from SpecialValuesHandler::handleSpecalizedValues() retVal:"+retVal);
			//Add other special values here such as business date
			return retVal;
		}
	public static String replaceSpecialValNGetStr(String inStr){
		log.info("SpecialValuesHandler::replaceSpecialValNGetStr() inStr:"+inStr);
		String specialVal = inStr.substring(inStr.lastIndexOf(ReportingFWUtil
				.getSpecialValIndr())+2,inStr.lastIndexOf(ReportingFWUtil.getSpecialValCloseIndr()));
		String processedSpecialVal = handleSpecalizedValues(specialVal);
		String retVal = StringUtils.replace(inStr, ReportingFWUtil.getSpecialValIndr(), "");
		retVal = StringUtils.replace(retVal, ReportingFWUtil.getSpecialValCloseIndr(), "");
		retVal = StringUtils.replace(retVal, specialVal, processedSpecialVal);
		log.info("SpecialValuesHandler::replaceSpecialValNGetStr() retVal:"+retVal);
		return retVal;
	}	
	
	public static void main(String a[]){
		System.out.println(handleSpecalizedValues("today+11:yyyyMMd"));
	}
}
