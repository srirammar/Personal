package com.otis.report.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ReportFWData {

	public List<ReportCols> getRepColumnList() {
		return repColumnList;
	}
	public ReportSql getRepSql() {
		return repSql;
	}
	public ReportFormat getRepFormat() {
		return repFormat;
	}
	public List<RptDynamicToken> getRepDynTokenList() {
		return repDynTokenList;
	}
	public  HashMap<String, String> getDynamicTokenValsMap() {
		return dynamicTokenValsMap;
	}
	public HashMap<String, String> getdTokenEvalMap() {
		return dTokenEvalMap;
	}	
	private List<ReportCols> repColumnList = new ArrayList<ReportCols>();
	public void setRepSql(ReportSql repSql) {
		this.repSql = repSql;
	}
	public void setRepFormat(ReportFormat repFormat) {
		this.repFormat = repFormat;
	}
	public boolean isOutputFileCreated() {
		return isOutputFileCreated;
	}
	public void setOutputFileCreated(boolean isOutputFileCreated) {
		this.isOutputFileCreated = isOutputFileCreated;
	}
	public int getRowCount() {
		return rowCount;
	}
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	public List<String> getHeaderFieldValStrList() {
		return headerFieldValStrList;
	}
	public List<ReportCols> getReArrangedColList() {
		return reArrangedColList;
	}
	public boolean isExcelFile() {
		return isExcelFile;
	}
	public void setExcelFile(boolean isExcelFile) {
		this.isExcelFile = isExcelFile;
	}
	public int getDataRowTokenCnt() {
		return dataRowTokenCnt;
	}
	public void setDataRowTokenCnt(int dataRowTokenCnt) {
		this.dataRowTokenCnt = dataRowTokenCnt;
	}
	
	private int dataRowTokenCnt;
	private boolean isOutputFileCreated = false;
	private boolean isExcelFile = false;
	public boolean isXlsxFile() {
		return isXlsxFile;
	}
	public void setXlsxFile(boolean isXlsxFile) {
		this.isXlsxFile = isXlsxFile;
	}
	private boolean isXlsxFile = false;
	private ReportSql repSql;
	private ReportFormat repFormat;
	private List<RptDynamicToken> repDynTokenList =  new ArrayList<RptDynamicToken>();
	private HashMap<String,String> dTokenEvalMap = new HashMap<String,String>();	
	private HashMap<String,String> dynamicTokenValsMap = new HashMap<String,String>();
	
	//internal variable state --> not mapped or fetched from DB
	private int rowCount;
	private List<String> headerFieldValStrList = new ArrayList<String>();
	private List<ReportCols> reArrangedColList = new ArrayList<ReportCols>();
	private HashMap<String,String> reportId2ShowNullMap = new HashMap<String,String>();
	
	public HashMap<String, String> getReportId2ShowZeroAsBlankMap() {
		return reportId2ShowZeroAsBlankMap;
	}
	public void setReportId2ShowZeroAsBlankMap(HashMap<String, String> reportId2ShowZeroAsBlankMap) {
		this.reportId2ShowZeroAsBlankMap = reportId2ShowZeroAsBlankMap;
	}
	private HashMap<String,String> reportId2ShowZeroAsBlankMap = new HashMap<String,String>();
	public HashMap<String, String> getReportId2ShowNullMap() {
		return reportId2ShowNullMap;
	}
	public void setReportId2ShowNullMap(HashMap<String, String> reportId2ShowNullMap) {
		this.reportId2ShowNullMap = reportId2ShowNullMap;
	}
	private HashMap<String,String> reportId2ShowNullAsBlankMap = new HashMap<String,String>();
	public HashMap<String, String> getReportId2ShowNullAsBlankMap() {
		return reportId2ShowNullAsBlankMap;
	}
	public void setReportId2ShowNullAsBlankMap(HashMap<String, String> reportId2ShowNullAsBlankMap) {
		this.reportId2ShowNullAsBlankMap = reportId2ShowNullAsBlankMap;
	}
}
