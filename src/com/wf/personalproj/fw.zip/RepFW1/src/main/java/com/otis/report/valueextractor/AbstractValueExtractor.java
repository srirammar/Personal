package com.otis.report.valueextractor;

import java.util.Calendar;
import java.util.Date;

import com.otis.report.model.ReportCols;
import com.otis.report.support.ValueFormatter;
import com.otis.report.util.ReportingFWUtil;

public abstract class AbstractValueExtractor implements IValueExtractor{
	protected String valueType = "value";
	protected String stringType = "string";
	protected String intType = "int";
	protected String floatType = "float";
	protected String doubleType = "double";
	protected String booleanType = "boolean";
	protected String dateType  = "date";
	protected String timestampType = "timestamp";
	protected String intAsStringType = "intasstring";
	protected String dateAsStringType  = "dateasstring";
	protected String timestampAsStringType = "timestampasstring";
	
	protected String handleValueTypeData(ReportCols repCols){
		String value = "";
		value = (repCols.getDefaultValue()==null)?"":repCols.getDefaultValue();
		//check if value is some significant word like TODAY/TODAY+n/TODAY-n
		if(value.toUpperCase().contains("TODAY")){
			 int nVal = 0;
			if(value.contains("+")){
				nVal = new Integer(value.substring(value.indexOf('+')+1,value.length()));
			}else if(value.contains("-")){
				nVal = new Integer(value.substring(value.indexOf('-')+1,value.length()));
			}
			return ValueFormatter.handleDateValue(ReportingFWUtil.addNDaysToToday(nVal),repCols.getWidth(),repCols.getAlignment(),repCols.getFormat(),"");
		 }
		 return ValueFormatter.handleStrWithAlignment(value,repCols.getWidth(),repCols.getAlignment());
	}
	
/*	@Override
	public double extracDoubleValFromSourceUsingReportCol(Object currentRowData, ReportCols repCols) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int extractIntValFromSourceUsingReportCol(Object currentRowData, ReportCols repCols) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Date extractDateValFromSourceUsingReportCol(Object currentRowData, ReportCols repCols) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Calendar extractTSValFromSourceUsingReportCol(Object currentRowData, ReportCols repCols) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}*/

}
