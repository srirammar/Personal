package com.otis.report.support;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class ValueFormatter {
/*	@Value("#{reportFWProp}")*/
	private static Map<String,String> reportFWProp = new HashMap<String,String>();
	
/*	@Value("#{boolValsDispMap}")*/
	private static Map<String,String> boolValsDispMap = new HashMap<String,String>();
	static{
		reportFWProp.put("Default_Bool_True" ,"yes");
		reportFWProp.put("Default_Bool_False" ,"N");
		reportFWProp.put("Default_Date_Format" ,"yyyyMMdd");
		reportFWProp.put("Default_Frac_Digits_DoubleNFloat" ,"2");
		reportFWProp.put("Possible_Delimiters" ,"!@#$%/,:;?|");
		
		boolValsDispMap.put("true/false,true" ,"true");
		boolValsDispMap.put("true/false,false" ,"false");
		boolValsDispMap.put("trueorfalse,true" ,"true");
		boolValsDispMap.put("trueorfalse,false" ,"false");
		boolValsDispMap.put("True/False,true" ,"true");
		boolValsDispMap.put("True/False,false" ,"False");
		boolValsDispMap.put("TrueorFalse,true" ,"true");
		boolValsDispMap.put("TrueorFalse,false" ,"False");
		boolValsDispMap.put("TrueOrFalse,true" ,"true");
		boolValsDispMap.put("TrueOrFalse,false" ,"False");
		boolValsDispMap.put("TRUE/FALSE,true" ,"true");
		boolValsDispMap.put("TRUE/FALSE,false" ,"FALSE");
		boolValsDispMap.put("TRUEorFALSE,true" ,"true");
		boolValsDispMap.put("TRUEorFALSE,false" ,"FALSE");
		boolValsDispMap.put("TRUEOrFALSE,true" ,"true");
		boolValsDispMap.put("TRUEOrFALSE,false" ,"FALSE");
		boolValsDispMap.put("TRUEORFALSE,true" ,"true");
		boolValsDispMap.put("TRUEORFALSE,false" ,"FALSE");
		boolValsDispMap.put("yes/no,true" ,"yes");
		boolValsDispMap.put("yes/no,false" ,"No");
		boolValsDispMap.put("yesorno,true" ,"yes");
		boolValsDispMap.put("yesorno,false" ,"No");
		boolValsDispMap.put("Yes/No,true" ,"yes");
		boolValsDispMap.put("Yes/No,false" ,"No");
		boolValsDispMap.put("YesorNo,true" ,"yes");
		boolValsDispMap.put("YesorNo,false" ,"No");
		boolValsDispMap.put("YesOrNo,true" ,"yes");
		boolValsDispMap.put("YesOrNo,false" ,"No");
		boolValsDispMap.put("YES/NO,true" ,"yes");
		boolValsDispMap.put("YES/NO,false" ,"NO");
		boolValsDispMap.put("YESorNO,true" ,"yes");
		boolValsDispMap.put("YESorNO,false" ,"NO");
		boolValsDispMap.put("y/n,true" ,"y");
		boolValsDispMap.put("y/n,false" ,"N");
		boolValsDispMap.put("yorn,true" ,"y");
		boolValsDispMap.put("yorn,false" ,"N");
		boolValsDispMap.put("Y / N,true" ,"Y");
		boolValsDispMap.put("Y / N,false" ,"N");
		boolValsDispMap.put("Y/N,true" ,"Y");
		boolValsDispMap.put("Y/N,false" ,"N");
		boolValsDispMap.put("Y or N,true" ,"Y");
		boolValsDispMap.put("Y or N,false" ,"N");
		boolValsDispMap.put("Y Or N,true" ,"Y");
		boolValsDispMap.put("Y Or N,false" ,"N");
		boolValsDispMap.put("Y OR N,true" ,"Y");
		boolValsDispMap.put("Y OR N,false" ,"N");
		boolValsDispMap.put("1 / 0,true" ,"1");
		boolValsDispMap.put("1 / 0,false" ,"0");
		boolValsDispMap.put("1/0,true" ,"1");
		boolValsDispMap.put("1/0,false" ,"0");
		boolValsDispMap.put("1or0,true" ,"1");
		boolValsDispMap.put("1or0,false" ,"0");
		boolValsDispMap.put("1OR0,true" ,"1");
		boolValsDispMap.put("1OR0,false" ,"0");
		boolValsDispMap.put("1Or0,true" ,"1");
		boolValsDispMap.put("1Or0,false" ,"0");

	}

	public static String handleDateValue(java.sql.Timestamp timestampVal,int width,String alignment,String format,String defVal){
		java.sql.Date dateVal = (timestampVal==null)?new java.sql.Date(System.currentTimeMillis())
								:new java.sql.Date(timestampVal.getTime());

		return handleDateValue(dateVal,width,alignment,format,defVal);
	}
	
	public static String handleTSAsStrValue(String timeStampStr,int width,String alignment,String format,String sourceFormat,String defVal){
		return handleDateAsStrValue(timeStampStr, width, alignment, format, sourceFormat, defVal);
	}
	public static String handleDateAsStrValue(String dateStr,int width,String alignment,String format,String sourceFormat,String defVal){
		String val = "";
		if(dateStr==null) {
			if(defVal!=null){
				val = defVal;
			}
			return handleStrWithAlignment(val,width,alignment);
		}
		Date dateVal = null;
		try{
			dateVal = new SimpleDateFormat(sourceFormat).parse(dateStr);
		}catch(Exception ex){
			//Suprress exception 
		}
		if(dateVal==null) {
			if(defVal!=null){
				val = defVal;
			}
			return handleStrWithAlignment(val,width,alignment);
		}
		if(format==null || format.isEmpty()||!isValidDateFormat(format)){
			format = reportFWProp.get("Default_Date_Format");
		}
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		val = sdf.format(dateVal);
		return handleStrWithAlignment(val,width,alignment);
	}
	
	public static String handleDateValue(java.sql.Date dateVal,int width,String alignment,String format,String defVal){
		String val = "";
		if(dateVal==null) {
			if(defVal!=null){
				val = defVal;
			}
			return handleStrWithAlignment(val,width,alignment);
		}

		if(format==null || format.isEmpty()||!isValidDateFormat(format)){
			format = reportFWProp.get("Default_Date_Format");
		}
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		try{
			val = sdf.format(dateVal);
		}catch(Exception ex){
			val = "";
		}
		
		return handleStrWithAlignment(val,width,alignment);
	}
	
	public static String handleDecimalNos(int intVal,int width,String alignment,String format){
		String val = "";
		if(StringUtils.isNotEmpty(format)&&isMainframeIntFormat(format)){
			val = formatMainframeIntVal(intVal+"",format);
		}else{		
			
			if(format==null || format.isEmpty()||isInValidDecFormat(format)){
				val = intVal+"";
			}else{
				DecimalFormat nc = new DecimalFormat();
				val = nc.format(intVal);
			}
		}
		return handleStrWithAlignment(val,width,alignment);
	}
	
	public static String handleDecimalNos(Float floatVal,int width,String alignment,String format){
		return handleDecimalNos(floatVal,width,alignment,format,false,false,false);
	}
	
	public static String handleDecimalNos(Float floatVal,int width,String alignment,String format
			,boolean displayNull,boolean displayZeroAsBlank,boolean displayNullAsBlank){
		String val = "";
		if(displayNull&&floatVal==null){
			return null;
		}
		if(displayNullAsBlank&&floatVal==null){
			return "";
		}
		if(displayZeroAsBlank&&floatVal==0){
			return "";
		}
		if(StringUtils.isNotEmpty(format)&&isMainframeDecimalFormat(format)){
			val = formatMainframeDoubleVal(floatVal+"",format);
		}else{		
			DecimalFormat dc = new DecimalFormat();

			if(format==null || format.isEmpty()|isInValidDecFormat(format)){
				int defFracDigits = Integer.parseInt(reportFWProp.get("Default_Frac_Digits_DoubleNFloat"));
				dc.setMaximumFractionDigits(defFracDigits);
				val = dc.format(floatVal);
			}else{
				dc = new DecimalFormat(format);
				val = dc.format(floatVal);
			}
		}
		return handleStrWithAlignment(val,width,alignment);
	}
	

	public static String handleDecimalNos(Double doubleVal,int width,String alignment,String format){
		return handleDecimalNos(doubleVal,width,alignment,format,false,false,false);
	}
	
	public static String handleDecimalNos(Double doubleVal,int width,String alignment,String format
			,boolean displayNull,boolean displayZeroAsBlank,boolean displayNullAsBlank){
		if(displayNull&&doubleVal==null){
			return null;
		}
		if(displayNullAsBlank&&doubleVal==null){
			return "";
		}
		if(displayZeroAsBlank&&doubleVal==0){
			return "";
		} 
		String val = "";
		if(StringUtils.isNotEmpty(format)&&isMainframeDecimalFormat(format)){
			val = formatMainframeDoubleVal(doubleVal+"",format);
		}else{
			DecimalFormat dc = new DecimalFormat();
			if(format==null || format.isEmpty()||isInValidDecFormat(format)){
				int defFracDigits = Integer.parseInt(reportFWProp.get("Default_Frac_Digits_DoubleNFloat"));
				dc.setMaximumFractionDigits(defFracDigits);
				val = dc.format(doubleVal);
			}else{
				dc = new DecimalFormat(format);
				val = dc.format(doubleVal);
			}			
		}
		return handleStrWithAlignment(val,width,alignment);
	}

	public static String handleDecimalNos(String doubleValAsStr,int width,String alignment,String format){
		return handleDecimalNos(doubleValAsStr,width,alignment,format,false,false,false);
	}
	
	public static String handleDecimalNos(String doubleValAsStr,int width,String alignment,String format
			,boolean displayNull,boolean displayZeroAsBlank,boolean displayNullAsBlank){
		if(displayNull&&(doubleValAsStr==null||doubleValAsStr.equalsIgnoreCase("null"))){
			return null;
		}
		if(displayNullAsBlank&&(doubleValAsStr==null||doubleValAsStr.equalsIgnoreCase("null"))){
			return "";
		}
		if(displayZeroAsBlank&&(doubleValAsStr.equalsIgnoreCase("0")||doubleValAsStr.equalsIgnoreCase("0.0")||doubleValAsStr.equalsIgnoreCase("0.00"))){
			return "";
		}
		String val = "";
		double doubleVal = 0.0;
		boolean returnEmptyStr = false;
		try{
			 doubleVal = Double.parseDouble(doubleValAsStr);
		}catch(Exception ex){
			returnEmptyStr = true;
		}
		if(returnEmptyStr){
			return handleStrWithAlignment(val,width,alignment);
		}
		if(StringUtils.isNotEmpty(format)&&isMainframeDecimalFormat(format)){
			val = formatMainframeDoubleVal(doubleVal+"",format);
		}else{
			DecimalFormat dc = new DecimalFormat();
			if(format==null || format.isEmpty()||isInValidDecFormat(format)){
				int defFracDigits = Integer.parseInt(reportFWProp.get("Default_Frac_Digits_DoubleNFloat"));
				dc.setMaximumFractionDigits(defFracDigits);
				val = dc.format(doubleVal);
			}else{
				dc = new DecimalFormat(format);
				val = dc.format(doubleVal);
			}			
		}
		return handleStrWithAlignment(val,width,alignment);
	}
	
	public static String handleStrWithAlignment(String inStr,int width,String alignment){
		if(inStr == null ){
			inStr =  "";
		}

		if(width<=0){
			if(StringUtils.isEmpty(inStr.trim())){
				return inStr.trim();
			}
			return inStr;
		}

		String retVal = "";
		if(inStr.length()>width){
			retVal = inStr.substring(0,width);
		}else{
			if(alignment==null || alignment.trim().isEmpty()){
				 alignment = "L";
			}
			if(alignment.toUpperCase().startsWith("L")){
				retVal = StringUtils.leftPad(inStr, width);
			}else{
				retVal = StringUtils.rightPad(inStr, width);
			}
		}
		
		return retVal;
	}
	
	public static String handleStrWithAlignment(String inStr,int width,String alignment,String defVal){
		if(inStr == null ){
			inStr =  defVal;
		}
		return handleStrWithAlignment(inStr,width,alignment);
	}
	
	public static String handleBooleanWithAlignment(String boolValAsStr,int width,String alignment,String format){
		boolean boolVal = false;
		if(StringUtils.containsAny(boolValAsStr.toUpperCase(), 'T','Y')){
			boolVal = true;
		}
		return handleBooleanWithAlignment(boolVal,width,alignment,format);
	}
	public static String handleBooleanWithAlignment(boolean bool,int width,String alignment,String format){
		if( format==null || format.isEmpty()){
			return getDefaultBool(bool);
		}
		format = format.replaceAll(" ", "");
		String displayStr = boolValsDispMap.get(format+","+(bool?"true":"false"));
		
		if(displayStr==null || displayStr.isEmpty()){
			displayStr =  getDefaultBool(bool);
		}
		
		return handleStrWithAlignment(displayStr,width,alignment);
	}
	
	private static String getDefaultBool(boolean b){
		return b? reportFWProp.get("Default_Bool_True")
					:reportFWProp.get("Default_Bool_False");
	}
	
	private static boolean isValidDateFormat(String inFormat){
		boolean isValid = true;
		try{
			new SimpleDateFormat(inFormat).format(new java.util.Date());
		}catch(Exception ex){
			isValid = false;
		}
		
		return isValid;
	}
	public static boolean isInValidDecFormat(String inFormat){
		for(int i=0;i<inFormat.length();i++){
			if(!isInAllowedCharArr(inFormat.charAt(i))){
				return true;
			}
		}
		return false;
	}
	
	private static boolean isInAllowedCharArr(char inChar){
		char[] allowedCharArr = {'$','#','.','0',','};
		for(int i=0;i<allowedCharArr.length;i++){
			if(inChar==allowedCharArr[i]) return true;
		}
		return false;
	}
	
	
	public static boolean isMainframeIntFormat(String format){
		   boolean retVal = false;
		   retVal = format.startsWith("9(") && format.endsWith(")");
		   retVal = retVal &&  (StringUtils.countMatches(format, "(")==1 && StringUtils.countMatches(format, ")")==1);
		   String fracDigit = StringUtils.substringBetween(format,"9(",")");
		   retVal = retVal && StringUtils.isNumeric(fracDigit) && !fracDigit.contains(".");
		   return retVal;		   
		}
		
		public static boolean isMainframeDecimalFormat(String format){
			   boolean retVal = false;
			   if(!format.startsWith("9(")){
				   return retVal;
			   }
			   boolean isVOrDotPresent = (format.toUpperCase().contains(".")||format.toUpperCase().contains("V"));
			   if(format.startsWith("9(") && !isVOrDotPresent){
				   return isMainframeIntFormat(format);
			   }
			   
			   String charToChk = format.toUpperCase().contains(".")?".":"V";

			   format = format.toUpperCase(); 
			   retVal = (format.startsWith("9(") && format.endsWith(")") && StringUtils.countMatches(format,charToChk)==1);
			   retVal = retVal && isMainframeIntFormat(StringUtils.substringBefore(format, charToChk)) && isMainframeIntFormat(StringUtils.substringAfter(format, charToChk)); 
			   return retVal;		   
		}
		public static String formatMainframeIntVal(String intVal,String format){
			return formatMainframeIntVal(intVal,format,"");
		}
		public static String formatMainframeIntVal(String intVal,String format,String alignment){
			String retVal = intVal;
			if(StringUtils.isEmpty(alignment)){
				alignment = "L";
			}
			int reqdLengthOfIntVal = Integer.parseInt(StringUtils.substringBetween(format,"9(",")"));
			if(retVal.length()<reqdLengthOfIntVal){
				retVal = alignment.equalsIgnoreCase("R")? StringUtils.rightPad(retVal, reqdLengthOfIntVal,'0')
						:StringUtils.leftPad(retVal, reqdLengthOfIntVal,'0');
			}	 
			return retVal;
		}
		
		public static String formatMainframeDoubleVal(String floatOrDoubleVal,String format){
			String retVal = ""; 

			format = format.toUpperCase();
			String intVal =  StringUtils.substringBefore(floatOrDoubleVal, ".");
			String fracDigits =  StringUtils.substringAfter(floatOrDoubleVal, ".");
			
			boolean isVOrDotPresent = (format.toUpperCase().contains(".")||format.toUpperCase().contains("V"));
			if(format.startsWith("9(")&&!isVOrDotPresent){
				return formatMainframeIntVal(StringUtils.substringBefore(floatOrDoubleVal, "."), format);
			}
			String charToChk = format.toUpperCase().contains(".")?".":"V";
			String alignmentAfterDecPoint = format.toUpperCase().contains(".")?"L":"R";
			
			String formatBeforeDecPoint =  StringUtils.substringBefore(format, charToChk);
			String formatAfterDecPoint =  StringUtils.substringAfter(format, charToChk);
			if(format.toUpperCase().contains(".")){
				retVal = formatMainframeIntVal(intVal,formatBeforeDecPoint)+"."+formatMainframeIntVal(fracDigits,formatAfterDecPoint,alignmentAfterDecPoint);
			}else{
				retVal = formatMainframeIntVal(intVal,formatBeforeDecPoint)+formatMainframeIntVal(fracDigits,formatAfterDecPoint,alignmentAfterDecPoint);
			}
			
			
			return retVal;
		}
}
