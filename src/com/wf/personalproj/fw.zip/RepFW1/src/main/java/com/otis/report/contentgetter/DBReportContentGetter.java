package com.otis.report.contentgetter;

import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.otis.report.content.ReportContentData;
import com.otis.report.dao.impl.GenericReportDAO;

public class DBReportContentGetter implements IReportContentGetter{
	private static final Logger log = Logger.getLogger(DBReportContentGetter.class);
	@Autowired
	private GenericReportDAO genericDao;
	@Override
	public ReportContentData fetchReportContent(String urlOrSql,String sourceOfData) {
		// TODO Auto-generated method stub
		log.info("Inside DBReportContentGetter::fetchReportContent()...");
		ReportContentData repData = new ReportContentData();
		ResultSet resultSet = genericDao.getResultSet(sourceOfData, urlOrSql);
		log.info("Inside DBReportContentGetter::fetchReportContent(). Obtained Resultset");
		repData.setReportContent(resultSet);
		
		log.info("Exiting from DBReportContentGetter::fetchReportContent()...");
		return repData;
	}

}
