package com.otis.report.util;

public class TableColNames {
	public static class ReportCols{
		public static String ReportId = "ReportId";
		public static String ColumnName = "ColumnName";
		public static String Width = "Width";
		public static String Alignment = "Alignment";
		public static String ColumnType = "ColumnType";
		public static String Format =  "Format";
		public static String ColIndex =  "ColIndex";
		public static String sourceDataFormat =  "sourceDataFormat";
		public static String defaultValue =  "defaultValue";
	}
	
	public static class ReportFormat{
		public static String ReportId = "ReportId";
		public static String ReportType = "ReportType";
		public static String dbName = "dbName";
		public static String header = "header";
		public static String footer = "footer";
		public static String disclaimer = "disclaimer";
		public static String body =  "body";
		public static String headerfieldvalues = "headerfieldvalues";
		public static String outputDir = "outputDir";
		public static String outputFile =  "outputFile";
		public static String SFTP =  "SFTP";
		public static String EMAIL =  "EMAIL";
		public static String createEmptyFile =  "createEmptyFile";
	}
	
	public static class ReportSql{
		public static String ReportId =  "ReportId";
		public static String HeaderValuesOrSqls = "HeaderValuesOrSqls";
		public static String FooterValuesOrSqls = "FooterValuesOrSqls";
		public static String DataValuesOrSqls =  "DataValuesOrSqls";		
	}
	
	public static class RptDynamicToken{
		public static String ReportId =  "ReportId";
		public static String ID = "ID";
		public static String DynamicToken = "DynamicToken";
		public static String DynamicTokenVal =  "DynamicTokenVal";
	}
	public static class AvailabilityCriteria{
		public static String Client = "Client";
		public static String TradeDate = "TradeDate";
		public static String QuantityHaircut_ETB = "QuantityHaircut_ETB";
		public static String QuantityHaircut_HTB = "QuantityHaircut_HTB";
		public static String QuantityHaircut_WARM = "QuantityHaircut_WARM";
		public static String QuantityHaircut_OTH = "QuantityHaircut_OTH";
		public static String RateHaircut = "RateHaircut";
		public static String Markets = "Markets";
		public static String Quantity = "Quantity";
		public static String Classification = "Classification";
		public static String RateEasy = "RateEasy";
		public static String RateWarm = "RateWarm";
		public static String RateHard = "RateHard";
		public static String RateOther = "RateOther";
		public static String Query = "Query";
		public static String Footer = "Footer";
		public static String Disclaimer = "Disclaimer";
		public static String ReportId = "ReportId";
		public static String ReportDescription = "ReportDescription";
		public static String ReportGroup = "ReportGroup";
	}
	public static class CABaseCriteria{
		public static String Symbol="Symbol"; 
		public static String Sedol ="Sedol"; 
		public static String Cusip ="Cusip"; 
		public static String ValidCusip ="ValidCusip"; 
		
		public static String ISIN  ="ISIN"; 
		public static String Quantity="Quantity"; 
		public static String Amount="Amount"; 
		public static String Rate  ="Rate"; 
		public static String FeeRate ="FeeRate"; 
		public static String RateDecimal ="RateDecimal"; 
		public static String RateInd ="RateInd"; 
		public static String RateHaircut ="RateHaircut"; 
		public static String IssuedCountryCode ="IssuedCountryCode"; 
		public static String Classification="Classification"; 		
	}
}
