package com.otis.report;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wfs.sbl.AvailabilityFeeds.RepInstanceFailedException;

public class ReportGeneratorMain {
	private static final Logger log = Logger.getLogger(ReportGeneratorMain.class);
	private static ApplicationContext ctx;

	public static void main(String[] args) throws Exception {
		String reportId = null;
		String dynaTokensFromCmdLine = null;
		if (args.length > 0) {
			log.info("Dynamic tokens are specified from command line. Reading dyna tokens from command line args..");
			dynaTokensFromCmdLine = args[0];
		}
		final long t = System.currentTimeMillis();
		reportId = System.getProperty("REPORTID");
		log.info("ReportId: " + reportId);
		ctx = new ClassPathXmlApplicationContext("classpath*:**/reportApplicationContext*.xml");
		ReportGenerator repGenrator = (ReportGenerator) ctx.getBean("ReportGenerator");
		log.info("Obtained ReportGenerator bean, calling displayReport()...");
		boolean success = false;
		try{
			success = repGenrator.displayReport(reportId, dynaTokensFromCmdLine);
		}catch(RepInstanceFailedException riFailedEx){
			log.error("**********************************************************************");
			log.error("********** Exception occurred with Report Instance webservice ********");
			log.error("**********************************************************************");
			riFailedEx.printStackTrace();
			riFailedEx.printErrorInfo();
			log.error("** Process completed with errors ..........");
			System.exit(-1);
		}
		catch(Exception ex){
			ex.printStackTrace();
			log.error("**********************************************************************");
			log.error("***** Exception occurred in ReportGenerator::displayReport() *********");
			log.error("**********************************************************************");
			log.error("** Process completed with errors ..........");
			System.exit(-1);
		}
	
		if(success){
			log.info("**********************************************************************");
			log.info("******************* Report Generation is success **********************");
			log.info(String.format("Time taken to generate report in %d ms.", System.currentTimeMillis() - t));
			log.info("Done with success.......");
			log.info("***********************************************************************");
			System.exit(0);
		}else{
			log.error("**********************************************************************");
			log.error("****************** Process completed with errors ******************");
			log.error("**********************************************************************");
			System.exit(-1);
		}
	}
}
