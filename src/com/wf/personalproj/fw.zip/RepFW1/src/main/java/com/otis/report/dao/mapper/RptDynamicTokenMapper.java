package com.otis.report.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.otis.report.model.RptDynamicToken;
import com.otis.report.util.TableColNames;

public class RptDynamicTokenMapper implements RowMapper<RptDynamicToken> {

	public RptDynamicToken mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		RptDynamicToken rdt = new RptDynamicToken();
		rdt.setReportId(arg0.getString(TableColNames.RptDynamicToken.ReportId));
		rdt.setID(arg0.getInt(TableColNames.RptDynamicToken.ID));
		rdt.setDynamicToken(arg0.getString(TableColNames.RptDynamicToken.DynamicToken));
		rdt.setDynamicTokenVal(arg0.getString(TableColNames.RptDynamicToken.DynamicTokenVal));
		return rdt;
	}
}	
 