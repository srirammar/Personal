package com.otis.report.support;

import java.util.Comparator;

import com.otis.report.model.ReportCols;

public class RepColsComparator implements Comparator<ReportCols>{
	@Override
	public int compare(ReportCols arg0, ReportCols arg1) {
		// TODO Auto-generated method stub
		return arg0.getColIndex().compareTo(arg1.getColIndex());
	}
}