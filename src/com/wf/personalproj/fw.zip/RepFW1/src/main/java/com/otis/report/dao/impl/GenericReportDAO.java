package com.otis.report.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import util.ConnectionMgr;
@Component("GenericReportDAO")
public class GenericReportDAO {
	private static final Logger log = Logger.getLogger(GenericReportDAO.class);
/*	private String env ="dev"; //Default is DEV
*/	@Value("#{dbId2DSMap}")
	private HashMap<String,String> dbIdDSMap;
	private String defaultDbId = null; //if not configured in ReportFW.properties then default is "sbldev"
	private String stdDateFormat;
	private String stdTimestampFormat;
	
	private Connection connection;
	private Statement statement;
	
	public void setDefaultDbId(String defaultDbId) {
		this.defaultDbId = defaultDbId;
	}
	public void setStdDateFormat(String stdDateFormat) {
		this.stdDateFormat = stdDateFormat;
	}

	public void setStdTimestampFormat(String stdTimestampFormat) {
		this.stdTimestampFormat = stdTimestampFormat;
	}
	
	private Connection getConnection(String dbId) throws Exception{
		log.info("Inside GenericReportDAO:: getConnection():--"+dbId);
		String ds = dbId.isEmpty()? this.defaultDbId :dbIdDSMap.get(dbId.toUpperCase());
		log.info("Inside GenericReportDAO:: ds:"+ds);
		return ConnectionMgr.getConnection(ds);
	}
	
	public String executeSQLAndFetchResult(String dbId,String sql){ 
		return executeSQLAndFetchResult(dbId,sql,false);
	}
	
	public String executeSQLAndFetchResult(String dbId,String sql,boolean wrapCharStrDatessInSingQuotes){ 
			log.info("Inside GenericReportDAO:: executeSQLAndFetchResult() sql:"+sql);
			if(sql.toUpperCase().contains("EXEC ")){
				return executeSPAndFetchResult(dbId,sql,wrapCharStrDatessInSingQuotes);
			}
		    String retVal = "";
			Connection conn = null;
			Statement stmt =null;
			ResultSet rs = null;
			try{
				conn = getConnection(dbId);
				log.info("GenericReportDAO:: getConnection() got conn:"+conn);
				stmt= conn.createStatement();
				log.info("GenericReportDAO:: getConnection() got stmt:"+stmt);
				
				rs = stmt.executeQuery(sql);
				log.info("GenericReportDAO:: getConnection() got rs:"+rs);
				retVal = extractValueFromRS(rs,wrapCharStrDatessInSingQuotes);
				log.info("GenericReportDAO:: getConnection() retVal:"+retVal);
			}catch(Exception ex){
					log.error("executeSQLAndFetchResult():Exception occurred while executing query .... ");
			}finally{
				try { if (rs != null) rs.close(); } catch (Exception e) {};
			    try { if (stmt != null) stmt.close(); } catch (Exception e) {};
			    try { if (conn != null) conn.close(); } catch (Exception e) {};
			}
		return retVal;
	}
	
	private String executeSPAndFetchResult(String dbId,String spCall,boolean wrapCharStrDatessInSingQuotes){
		log.info("Inside GenericReportDAO:: executeSPAndFetchResult() spCall value:"+spCall);
		String retVal = "";
		Connection conn = null;
		CallableStatement cStmt =null;
		ResultSet rs = null;
		try{
			conn = getConnection(dbId);
			log.info("GenericReportDAO:: getConnection() got conn:"+conn);
			cStmt = conn.prepareCall(spCall);
			log.info("GenericReportDAO:: getConnection() got cStmt:"+cStmt);
			rs = cStmt.executeQuery();
			log.info("GenericReportDAO:: getConnection() got rs:"+rs);
			retVal = extractValueFromRS(rs,wrapCharStrDatessInSingQuotes);
			log.info("GenericReportDAO:: getConnection() retVal: "+retVal);
		}catch(Exception ex){
				log.error("executeSQLAndFetchResult():Exception occurred while executing query .... ");
		}finally{
			try { if (rs != null) rs.close(); } catch (Exception e) {};
		    try { if (cStmt != null) cStmt.close(); } catch (Exception e) {};
		    try { if (conn != null) conn.close(); } catch (Exception e) {};
		}
		return retVal;		
	}
	
	private String extractValueFromRS(ResultSet rs,boolean wrapCharStrDatessInSingQuotes) throws Exception{
		log.info("Inside GenericReportDAO:: extractValueFromRS() ");
		String retVal = "";
		ResultSetMetaData rmd = rs.getMetaData();
		log.info("Inside GenericReportDAO:: extractValueFromRS() got rmd"+rmd);
		int noOfCols = rmd.getColumnCount();
		log.info("Inside GenericReportDAO:: extractValueFromRS() noOfCols"+noOfCols);
		while(rs.next()){
			for(int i=1;i<=noOfCols;i++){
				int colType = rmd.getColumnType(i);
				log.info("Inside GenericReportDAO:: extractValueFromRS() colType"+colType);
				switch(colType){
					case java.sql.Types.BOOLEAN:
						retVal = rs.getBoolean(i)+""; break;
					case java.sql.Types.FLOAT:
						retVal = rs.getFloat(i)+""; break;
					case java.sql.Types.DOUBLE:
						retVal = rs.getDouble(i)+""; break;
					case java.sql.Types.CHAR:
						retVal = rs.getString(i)+""; break;
					case java.sql.Types.INTEGER:
						retVal = rs.getInt(i)+""; break;
					case java.sql.Types.VARCHAR:
						retVal = rs.getString(i); break;
					case java.sql.Types.NVARCHAR:
						retVal = rs.getString(i); break;
					case java.sql.Types.DATE:
						retVal = converToDateInYYYYMMDD(rs.getDate(i)); break;
					case java.sql.Types.TIMESTAMP:
						retVal = converToDateInYYYYMMDDHH24MMSS(rs.getTimestamp(i)); break;						
				}
				log.info("Inside GenericReportDAO:: extractValueFromRS() retVal"+retVal);
				if(wrapCharStrDatessInSingQuotes){
					if(colType==java.sql.Types.CHAR||colType==java.sql.Types.VARCHAR
							||colType==java.sql.Types.NVARCHAR||colType==java.sql.Types.DATE||colType==java.sql.Types.TIMESTAMP){
						log.info("Inside GenericReportDAO:: extractValueFromRS() wrapping retVal in single quotes...");
						retVal = "'"+retVal+"'";
					}
				}
			}					
		}	

		return retVal;
	}
	
	public ResultSet getResultSet(String dbId,String sql){ 
		log.info("Inside GenericReportDAO:: getResultSet() ");
		ResultSet rs = null;
		try{
			if(this.statement==null){
				log.info("The connection and statement are not opened trying to open statement....");
				boolean successFlag = openStatement(dbId);
				if(!successFlag){
					log.error("getResultSet():Exception occurred while trying to open statement.... ");
				}
			}
			rs = this.statement.executeQuery(sql);
		}catch(Exception ex){
				log.error("getResultSet():Exception occurred while executing query .... ");
				log.error("Closing connection and statement .... ");
				closeStmtAndConn();
		}
		log.info("Exiting from GenericReportDAO:: getResultSet() ");
		return rs;
	}
	
	
	
	public boolean openStatement(String dbId){
		log.info("Inside  GenericReportDAO:: openStatement() ");
		boolean sucessFlag = false;
		try{
			this.connection = getConnection(dbId);
			this.statement = this.connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
				    ResultSet.CONCUR_READ_ONLY);
			sucessFlag = true;
		}catch(SQLException ex){
			log.error("openStatement(dbId):Exception occurred while trying to create connection and open stmt .... ");
			if(this.statement==null&&this.connection!=null){
				try{this.connection.close();} catch(Exception ex1){}
				sucessFlag = false;
			}
		}catch(Exception ex){
			log.error("openStatement(dbId):Exception occurred while trying to create connection and open stmt .... ");
			if(this.statement==null&&this.connection!=null){
				try{this.connection.close();} catch(Exception ex1){}
				sucessFlag = false;
			}
		}
		log.info("Exiting from GenericReportDAO:: openStatement() sucessFlag"+sucessFlag);
		return sucessFlag;
	}
	
	public void closeStmtAndConn(){
		log.info("Inside  GenericReportDAO:: closeStmtAndConn() ");
		if(this.statement!=null){
			log.info("GenericReportDAO:: closeStmtAndConn() closing statement... ");
			try{this.statement.close();} catch(Exception ex){}
		}
		if(this.connection!=null){
			log.info("GenericReportDAO:: closeStmtAndConn() closing connection... ");
			try{this.connection.close();} catch(Exception ex){}
		}
		log.info("Exiting from  GenericReportDAO:: closeStmtAndConn() ");
	}
	private String converToDateInYYYYMMDD(Date inDate){
		return new SimpleDateFormat(stdDateFormat).format(inDate);
	}
	private String converToDateInYYYYMMDDHH24MMSS(Timestamp inDate){
		return new SimpleDateFormat(stdTimestampFormat).format(inDate);
	}
}
