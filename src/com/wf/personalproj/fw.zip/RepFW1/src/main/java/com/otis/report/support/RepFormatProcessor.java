package com.otis.report.support;

import java.text.MessageFormat;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.model.ReportFWData;
import com.otis.report.util.FormatValidator;
import com.otis.report.util.ReportingFWUtil;


public class RepFormatProcessor {
	@Resource(name = "reportFWProps")
	private Properties reportFWProps;
	private String tokenOpenIndr;
	private String tokenCloseIndr;
	private String sqlOrValuesDelim;
	private String inValidFormatMsg;
	private String inValidTokenCntMsg;

	private String lineSepIndr;
	private String sepcialValIndr;
	private String rowCountIndr;
	
	private static final Logger log = Logger.getLogger(RepFormatProcessor.class);
	
	public void setRowCountIndr(String rowCountIndr) {
		this.rowCountIndr = rowCountIndr;
	}

	private int rowCount;
	
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public void setTokenOpenIndr(String tokenOpenIndr) {
		this.tokenOpenIndr = tokenOpenIndr;
	}

	public void setTokenCloseIndr(String tokenCloseIndr) {
		this.tokenCloseIndr = tokenCloseIndr;
	}
	
	public void setSqlOrValuesDelim(String sqlOrValuesDelim) {
		this.sqlOrValuesDelim = sqlOrValuesDelim;
	}

	public void setInValidFormatMsg(String inValidFormatMsg) {
		this.inValidFormatMsg = inValidFormatMsg;
	}

	public void setInValidTokenCntMsg(String inValidTokenCntMsg) {
		this.inValidTokenCntMsg = inValidTokenCntMsg;
	}
	public void setLineSepIndr(String lineSepIndr) {
		this.lineSepIndr = lineSepIndr;
	}

	public void setSepcialValIndr(String sepcialValIndr) {
		this.sepcialValIndr = sepcialValIndr;
	}
	
	public StringBuilder processFormattedMsg(String inFormat,ReportFWData reportFWData
			,String sqlsOrDataValues,String type,GenericReportDAO genericDao) throws Exception{
		log.info("RepFormatProcessor::processFormattedMsg() inFormat"+inFormat);
		log.info("RepFormatProcessor::processFormattedMsg() sqlsOrDataValues"+sqlsOrDataValues);
		log.info("RepFormatProcessor::processFormattedMsg() type"+type);
		log.info("RepFormatProcessor::processFormattedMsg() sepcialValIndr"+sepcialValIndr);
		log.info("RepFormatProcessor::processFormattedMsg() rowCountIndr"+rowCountIndr);
		
		if(!FormatValidator.validateFormat(inFormat,tokenOpenIndr,tokenCloseIndr)){
			throw new Exception(new MessageFormat(inValidFormatMsg).format(type));
		}
		StringBuilder strBuilder = new StringBuilder("");
		int tokenCnt = 0;
		String nextValueOrSql = "";
		String sqlExecResult = "";
		
		MessageFormat msgFormat = new MessageFormat(inFormat);
		tokenCnt = StringUtils.countMatches(inFormat, tokenOpenIndr);
		log.info("RepFormatProcessor::processFormattedMsg() tokenCnt"+tokenCnt);
		Object[] mfTokens = new Object[tokenCnt];

		
		int valueSepCnt = StringUtils.countMatches(sqlsOrDataValues, sqlOrValuesDelim);
		log.info("RepFormatProcessor::processFormattedMsg() valueSepCnt"+valueSepCnt);
		if(tokenCnt>0&&tokenCnt!=(valueSepCnt+1)){
			throw new Exception(new MessageFormat(inValidTokenCntMsg).format(new Object[]{type,type}));
		}

		StringTokenizer st = new StringTokenizer(sqlsOrDataValues,";"); int index =0;
		while(st.hasMoreTokens()){
			nextValueOrSql =st.nextToken();
			log.info("RepFormatProcessor::processFormattedMsg() nextValueOrSql "+nextValueOrSql);
			if(!ReportingFWUtil.isValidSQL(nextValueOrSql)){
				log.info("RepFormatProcessor::processFormattedMsg() nextValueOrSql is not valid sql..");
				if(!nextValueOrSql.startsWith(sepcialValIndr)){
					log.info("RepFormatProcessor::processFormattedMsg() nextValueOrSql is NOT special value..");
					mfTokens[index] = nextValueOrSql;++index; 
				}else{
					 if(nextValueOrSql.toLowerCase().startsWith(rowCountIndr)){
						 log.info("RepFormatProcessor::processFormattedMsg() nextValueOrSql is not row count..");
						 //this must be row count
						 //if row count contains formatting info then format the row count accordingly
						 if(nextValueOrSql.contains(":")){
							 log.info("RepFormatProcessor::processFormattedMsg() row count contains formatting information..");
							 mfTokens[index] = getFormattedRowCnt(rowCount+"",nextValueOrSql.substring(2,nextValueOrSql.length()-1).split(":")); ++index;
						 }else{
							 mfTokens[index] = rowCount+"";++index; 
						 }	 
					 }else{
						 log.info("RepFormatProcessor::processFormattedMsg() nextValueOrSql is special value..");
							//handle specialized values other than such as today and filler etc
							mfTokens[index] = SpecialValuesHandler.handleSpecalizedValues
									(nextValueOrSql.substring(2, nextValueOrSql.length()-1));++index; 
					 }

				}
			}else{ //token must be sql or dynamic sql, determine accordingly, execute and fetch result
				log.info("RepFormatProcessor::processFormattedMsg() nextValueOrSql is special value..");
				nextValueOrSql =
						ReportingFWSqlProcessor.processReportingFWSql(nextValueOrSql,genericDao,reportFWData);
				log.info("RepFormatProcessor::processFormattedMsg() processed nextValueOrSql"+nextValueOrSql);
				sqlExecResult = genericDao.executeSQLAndFetchResult(reportFWData.getRepFormat().getDbName()
												,nextValueOrSql);
				log.info("RepFormatProcessor::processFormattedMsg() sqlExecResult by processed nextValueOrSql "
												+sqlExecResult);
				mfTokens[index] = sqlExecResult;++index; 
			}
		}
		strBuilder.append(msgFormat.format(mfTokens));
		
		String strToChk = strBuilder.toString();
		if(strToChk.contains(lineSepIndr)){
			log.info("RepFormatProcessor::processFormattedMsg()  strToChk contains "+lineSepIndr);
			String[] tokenArray = new String[10];int i=-1;
			boolean exitLoop = false;
			while(!exitLoop){
				int slashNIndex = strToChk.indexOf(lineSepIndr);
				if(slashNIndex>=0) {
					tokenArray[++i] = strToChk.substring(0, slashNIndex);
					strToChk = strToChk.substring(slashNIndex+2);
				}else{
					 exitLoop = true;
					if(!strToChk.isEmpty()){
						tokenArray[++i] = strToChk;
					}
				}

			}
			strBuilder = new StringBuilder("");
			int cnt=-1;
			for(String token:tokenArray){
				if(token==null || token.isEmpty()) continue;
				++cnt;
				strBuilder.append(token);
				if(cnt<i){
					strBuilder.append(System.lineSeparator());
				}
			}
		}
		log.info("RepFormatProcessor::processFormattedMsg()  strBuilder value "+strBuilder.toString());
		return strBuilder;
	}
	
	private String getFormattedRowCnt(String rowCntVal,String[] rowCntFormattingInfo){
		log.info("RepFormatProcessor::getFormattedRowCnt()   rowCntVal: "+rowCntVal);
		log.info("RepFormatProcessor::getFormattedRowCnt()   rowCntFormattingInfo size: "+rowCntFormattingInfo.length);
		//ignore rowCntFormattingInfo[0] ==>it must have been count
		String retVal = (ValueFormatter.isMainframeIntFormat(rowCntFormattingInfo[1]))?ValueFormatter.formatMainframeIntVal(rowCntVal, rowCntFormattingInfo[1])
				:StringUtils.leftPad(rowCntVal, Integer.parseInt(rowCntFormattingInfo[1]),'0');
		log.info("RepFormatProcessor::getFormattedRowCnt()   retVal: "+retVal);
		return retVal;
	}
}
