package com.otis.report.model;

public class ReportField {
	
	private String reportid;
	private String name;
	private String clazzName;
	private String expression;
	
	
	public String getReportid() {
		return reportid;
	}
	public void setReportid(String reportid) {
		this.reportid = reportid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClazzName() {
		return clazzName;
	}
	public void setClazzName(String clazzName) {
		this.clazzName = clazzName;
	}
	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}
	@Override
	public String toString() {
		return "ReportField [reportid=" + reportid + ", name=" + name
				+ ", clazzName=" + clazzName + ", expression=" + expression
				+ "]";
	}


	
	
	

}
