package com.otis.report.model;

public class ReportFormat {
	public String getReportid() {
		return reportid;
	}
	public void setReportid(String reportid) {
		this.reportid = reportid;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getFooter() {
		return footer;
	}
	public void setFooter(String footer) {
		this.footer = footer;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getHeaderfieldvalues() {
		return headerfieldvalues;
	}
	public void setHeaderfieldvalues(String headerfieldvalues) {
		this.headerfieldvalues = headerfieldvalues;
	}
	public String getOutputDir() {
		return outputDir;
	}
	public void setOutputDir(String outputDir) {
		this.outputDir = outputDir;
	}
	public String getOutputFile() {
		return outputFile;
	}
	public void setOutputFile(String outputFile) {
		this.outputFile = outputFile;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getDisclaimer() {
		return disclaimer;
	}
	public void setDisclaimer(String disclaimer) {
		this.disclaimer = disclaimer;
	}	

	private String reportid;
	private String reportType;
	private String header;
	private String footer;

	private String disclaimer;
	private String body;
	private String headerfieldvalues;
	private String dbName;
	private String outputDir;
	private String outputFile;
	
	private String replacedFileName;
	public String getReplacedFileName() {
		return replacedFileName;
	}
	public void setReplacedFileName(String replacedFileName) {
		this.replacedFileName = replacedFileName;
	}
	public String getSftp() {
		return sftp;
	}
	public void setSftp(String sftp) {
		this.sftp = sftp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	private String sftp;
	private String email;
	public String getCreateEmptyFile() {
		return createEmptyFile;
	}
	public void setCreateEmptyFile(String createEmptyFile) {
		this.createEmptyFile = createEmptyFile;
	}

	private String createEmptyFile;
}
