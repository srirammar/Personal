package com.otis.report.util;

import org.apache.commons.lang3.StringUtils;

public class FormatValidator {
	public static boolean validateFormat(String inFormat,String tokenOpenIndr,String tokenCloseIndr){
		//SRIRAM  - TO FINISH : ====> for now return true

		if(StringUtils.countMatches(inFormat, tokenOpenIndr)!=StringUtils.countMatches(inFormat, tokenCloseIndr)){
			return false;
		}else{
				//Tokens are valid with the presence of { and immediate}, next check their validity
			int firstFBOpenIndex = 0; int i=-1;
			int nextFBCloseIndex = 0;
			int[] tokenDigitArr = new int[StringUtils.countMatches(inFormat, tokenOpenIndr)];
			StringBuilder chkStr = new StringBuilder(inFormat);
			
			 while(chkStr.toString().trim().length()>0 && chkStr.toString().indexOf(tokenOpenIndr)!=-1){
				 firstFBOpenIndex = chkStr.toString().indexOf(tokenOpenIndr);
				  nextFBCloseIndex = chkStr.toString().indexOf(tokenCloseIndr);
				  String nextDigit = chkStr.substring(firstFBOpenIndex+1,nextFBCloseIndex);
				 if(!StringUtils.isNumeric(nextDigit)){
					 return false;
				 }else{
					 tokenDigitArr[++i] = Integer.parseInt(nextDigit);
				 }
				 chkStr = new StringBuilder(chkStr.toString().substring(nextFBCloseIndex+1));
			 }
			 
			 //The tokens must be in sorted order so that the matches can happen in particular order otherwise it might lead to ambiguity
			 //and bugs in the report
			 if(!isSorted(tokenDigitArr)){
				 return false;
			 }
		}
		return true;
	}
	
	public static boolean isSorted(int[] a) 
	{
		boolean retVal = true;
	    int i;
	    for(i = 0; i < a.length-1; i++){
	    	if(i+1>=a.length) break;
	        if (a[i] > a[i+1]) {
	        	retVal = false;break;
	        } 
	    }
	    return retVal;
	}
}
