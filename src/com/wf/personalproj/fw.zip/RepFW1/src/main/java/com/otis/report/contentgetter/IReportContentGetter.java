package com.otis.report.contentgetter;

import com.otis.report.content.ReportContentData;

public interface IReportContentGetter {
	public ReportContentData fetchReportContent(String urlOrSql,String sourceOfData);
}
