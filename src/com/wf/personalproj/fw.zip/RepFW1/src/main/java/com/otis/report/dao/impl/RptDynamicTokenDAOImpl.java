package com.otis.report.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.otis.report.dao.RptDynamicTokenDAO;
import com.otis.report.model.RptDynamicToken;

@Component("RptDynamicTokenDAOImpl")
public class RptDynamicTokenDAOImpl implements RptDynamicTokenDAO {
	@Autowired
	private RowMapper<RptDynamicToken> rptDynaTokenMapper;
	@Autowired
	private SimpleJdbcCall sblDataSource;
	private String repDynaTokenSql;
	
	public void setRepDynaTokenSql(String repDynaTokenSql) {
		this.repDynaTokenSql = repDynaTokenSql;
	}

	public List<RptDynamicToken> getRptDynamicTokens() {
		 return  (List<RptDynamicToken>) sblDataSource.getJdbcTemplate().query(repDynaTokenSql,rptDynaTokenMapper);
	}
	public List<RptDynamicToken> getRptDynamicTokens(String reportId){
		List<RptDynamicToken> filteredList = new ArrayList<RptDynamicToken>();
		for(RptDynamicToken rdt:getRptDynamicTokens()){
			if(rdt.getReportId().equalsIgnoreCase(reportId)){
				filteredList.add(rdt);
			}
		}
	
		return filteredList;
	}
}
