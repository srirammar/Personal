package com.otis.report.valueextractor;

import java.sql.ResultSet;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;

import com.otis.report.model.ReportCols;
import com.otis.report.model.ReportFWData;
import com.otis.report.support.ValueFormatter;

public class ResultSetValueExtractor extends AbstractValueExtractor {
	
	@Override
	public String extractValFromSourceUsingReportCol(Object currentRowData, ReportCols repCols,ReportFWData reportFWData)
			throws Exception {
		// TODO Auto-generated method stub
		ResultSet resultSet = (ResultSet)currentRowData;
		
		if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(valueType)
				||repCols.getClazzType().isEmpty()
				||repCols.getClazzType()==null){
			return super.handleValueTypeData(repCols);
		  } 
		
		String alignment = repCols.getAlignment();
		int width = repCols.getWidth();
		String format = repCols.getFormat();
		String defVal = repCols.getDefaultValue();
		String sourceFormat = repCols.getSourceDataFormat();
		
		String displayNullStr = reportFWData.getReportId2ShowNullMap().get(repCols.getReportid());
		boolean displayNull = false;
		if(displayNullStr!=null && displayNullStr.equalsIgnoreCase("true")){
			displayNull = true;
		}
		String displayNullAsBlankStr = reportFWData.getReportId2ShowNullAsBlankMap().get(repCols.getReportid());
		boolean displayNullAsBlank = false;
		if(displayNullAsBlankStr!=null && displayNullAsBlankStr.equalsIgnoreCase("true")){
			displayNullAsBlank = true;
		}
		String displayZeroAsBlankStr = reportFWData.getReportId2ShowZeroAsBlankMap().get(repCols.getReportid());
		boolean displayZeroAsBlank = false;
		if(displayZeroAsBlankStr!=null && displayZeroAsBlankStr.equalsIgnoreCase("true")){
			displayZeroAsBlank = true;
		}
		if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(stringType)){
			return ValueFormatter.handleStrWithAlignment(resultSet.getString(repCols.getName()),width,alignment,defVal);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(intType)){
			return ValueFormatter.handleStrWithAlignment(resultSet.getInt(repCols.getName())+"",width,alignment,defVal);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(floatType)){
			Float fVal = resultSet.getFloat(repCols.getName());
			if(resultSet.wasNull() && (displayNull||displayNullAsBlank)){
				fVal = null;
			}
			return ValueFormatter.handleDecimalNos(fVal,width,alignment,format,displayNull,displayZeroAsBlank,displayNullAsBlank);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(doubleType)){
			Double dVal = resultSet.getDouble(repCols.getName());
			if(resultSet.wasNull() &&  (displayNull||displayNullAsBlank)){
				dVal = null;
			}
			return ValueFormatter.handleDecimalNos(dVal,width,alignment,format,displayNull,displayZeroAsBlank,displayNullAsBlank);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(booleanType)){
			return ValueFormatter.handleBooleanWithAlignment(resultSet.getBoolean(repCols.getName()),width,alignment,format);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(dateType)){
			return ValueFormatter.handleDateValue(resultSet.getDate(repCols.getName()),width,alignment,format,defVal);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(timestampType)){
			return ValueFormatter.handleDateValue(resultSet.getTimestamp(repCols.getName()),width,alignment,format,defVal);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(dateAsStringType)){
			return ValueFormatter.handleDateAsStrValue(resultSet.getString(repCols.getName()),width,alignment,format,sourceFormat,defVal);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(timestampAsStringType)){
			return ValueFormatter.handleTSAsStrValue(resultSet.getString(repCols.getName()),width,alignment,format,sourceFormat,defVal);
		}
		
		return "";
	}

}	
