package com.otis.report.exception;

public class NoDataRowsExistException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoDataRowsExistException(String msg){
		super(msg);
	}
}
