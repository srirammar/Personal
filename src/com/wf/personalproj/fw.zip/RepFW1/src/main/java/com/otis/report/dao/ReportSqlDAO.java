package com.otis.report.dao;

import java.util.List;

import com.otis.report.model.ReportSql;

public interface ReportSqlDAO {
	public List<ReportSql> getReportSql();
	public ReportSql getReportSql(String reportId);
}
