package com.otis.report.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.otis.report.model.ReportFormat;
import com.otis.report.util.TableColNames;

public class ReportFormatMapper implements RowMapper<ReportFormat> {

	public ReportFormat mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		ReportFormat repFormat = new ReportFormat();
		repFormat.setReportid(arg0.getString(TableColNames.ReportFormat.ReportId));
		repFormat.setReportType(arg0.getString(TableColNames.ReportFormat.ReportType));
		repFormat.setDbName(arg0.getString(TableColNames.ReportFormat.dbName));
		repFormat.setHeader(arg0.getString(TableColNames.ReportFormat.header));
		repFormat.setFooter(arg0.getString(TableColNames.ReportFormat.footer));
		repFormat.setDisclaimer(arg0.getString(TableColNames.ReportFormat.disclaimer));
		repFormat.setBody(arg0.getString(TableColNames.ReportFormat.body));
		repFormat.setHeaderfieldvalues(arg0.getString(TableColNames.ReportFormat.headerfieldvalues));
		repFormat.setOutputDir(arg0.getString(TableColNames.ReportFormat.outputDir));
		repFormat.setOutputFile(arg0.getString(TableColNames.ReportFormat.outputFile));
		repFormat.setSftp(arg0.getString(TableColNames.ReportFormat.SFTP));
		repFormat.setEmail(arg0.getString(TableColNames.ReportFormat.EMAIL));
		repFormat.setCreateEmptyFile(arg0.getString(TableColNames.ReportFormat.createEmptyFile));
		return repFormat;
	}
}
