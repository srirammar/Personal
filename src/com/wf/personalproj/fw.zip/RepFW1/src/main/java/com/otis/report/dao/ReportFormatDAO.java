package com.otis.report.dao;

import java.util.List;

import com.otis.report.model.ReportFormat;

public interface ReportFormatDAO {
	public List<ReportFormat> getReportFormat();
	public ReportFormat getReportFormat(String reportId);
}
