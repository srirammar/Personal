package com.otis.report.contentgetter;

import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.otis.report.content.ReportContentData;
import com.otis.report.util.RESTServiceCaller;

public class RWSReportContentGetter implements IReportContentGetter{
	private static final Logger log = Logger.getLogger(RWSReportContentGetter.class);
	@Override
	public ReportContentData fetchReportContent(String urlOrSql, String sourceOfData) {
		log.info("Inside RWSReportContentGetter::fetchReportContent()...");
		// TODO Auto-generated method stub
		ReportContentData repData = new ReportContentData();
		String  jsonResp = RESTServiceCaller.callRest(urlOrSql);

		Gson gson = new Gson();
		ArrayList<Map<String, String>> jsonDataAsListOfMaps = gson.fromJson(jsonResp, new TypeToken<ArrayList<Map<String, String>>>() {}.getType());
		
		log.info("Inside DBReportContentGetter::fetchReportContent(). Obtained data from rest service as list of hash maps.....");
		repData.setReportContent(jsonDataAsListOfMaps);
		
		log.info("Exiting from RWSReportContentGetter::fetchReportContent()...");
		return repData;
	}

}
