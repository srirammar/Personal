package com.otis.report.valueextractor;

import java.util.Map;

import com.otis.report.model.ReportCols;
import com.otis.report.model.ReportFWData;
import com.otis.report.support.ValueFormatter;

public class RWSValueExtractor extends AbstractValueExtractor{

	private static final String EMPTY = " ";
	@Override
	public String extractValFromSourceUsingReportCol(Object currentRowData, ReportCols repCols,ReportFWData reportFWData)
			throws Exception {
		// TODO Auto-generated method stub
		Map<String, String> currRowAsKeyValMap = (Map<String, String>)currentRowData;
		
		if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(valueType)
				||repCols.getClazzType().isEmpty()
				||repCols.getClazzType()==null){
			return super.handleValueTypeData(repCols);
		  } 
			String alignment = repCols.getAlignment();
		int width = repCols.getWidth();
		String format = repCols.getFormat();
		String sourceDataFormat = repCols.getSourceDataFormat();
		String defVal = repCols.getDefaultValue();
		
		String currVal = currRowAsKeyValMap.get(repCols.getName());
		if(currVal ==null){
			if(defVal==null){
				 ValueFormatter.handleStrWithAlignment(EMPTY,width,alignment);
			}
			currVal = defVal; 
		}

		String displayNullStr = reportFWData.getReportId2ShowNullMap().get(repCols.getReportid());
		boolean displayNull = false;
		if(displayNullStr!=null && displayNullStr.equalsIgnoreCase("true")){
			displayNull = true;
		}
		String displayNullAsBlankStr = reportFWData.getReportId2ShowNullAsBlankMap().get(repCols.getReportid());
		boolean displayNullAsBlank = false;
		if(displayNullAsBlankStr!=null && displayNullAsBlankStr.equalsIgnoreCase("true")){
			displayNullAsBlank = true;
		}
		String displayZeroAsBlankStr = reportFWData.getReportId2ShowZeroAsBlankMap().get(repCols.getReportid());
		boolean displayZeroAsBlank = false;
		if(displayZeroAsBlankStr!=null && displayZeroAsBlankStr.equalsIgnoreCase("true")){
			displayZeroAsBlank = true;
		}
		if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(stringType)){
			return ValueFormatter.handleStrWithAlignment(currVal,width,alignment);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(intType)){
			return (format==null)?ValueFormatter.handleStrWithAlignment(currVal,width,alignment)
						: ValueFormatter.handleDecimalNos(currVal,width,alignment,format);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(floatType)){
			return ValueFormatter.handleDecimalNos(currVal,width,alignment,format,displayNull,displayZeroAsBlank,displayNullAsBlank);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(doubleType)){
			return ValueFormatter.handleDecimalNos(currVal,width,alignment,format,displayNull,displayZeroAsBlank,displayNullAsBlank);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(booleanType)){
			return ValueFormatter.handleBooleanWithAlignment(currVal,width,alignment,format);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(dateAsStringType)){
			return (sourceDataFormat!=null)?ValueFormatter.handleDateAsStrValue(currVal,width,alignment,format,sourceDataFormat,defVal)
				:ValueFormatter.handleStrWithAlignment(currVal,width,alignment);
		}else if(repCols.getClazzType().toLowerCase().equalsIgnoreCase(timestampAsStringType)){
			return (sourceDataFormat!=null)?ValueFormatter.handleTSAsStrValue(currVal,width,alignment,format,sourceDataFormat,defVal)
					:ValueFormatter.handleStrWithAlignment(currVal,width,alignment);
		}
		
		return "";
	}
}
