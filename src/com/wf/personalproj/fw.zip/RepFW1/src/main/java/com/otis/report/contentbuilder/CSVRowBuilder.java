package com.otis.report.contentbuilder;

import java.text.MessageFormat;

import com.otis.report.model.ReportFWData;
import com.otis.report.valueextractor.IValueExtractor;

public class CSVRowBuilder implements RowBuilder {
	@Override
	public String prepareCurrentRow(Object reportContentData,ReportFWData reportFWData,IValueExtractor valueExtractor) throws Exception{
		MessageFormat drMsgFormat = new MessageFormat(reportFWData.getRepFormat().getBody());
		Object[] drTokens = new Object[reportFWData.getDataRowTokenCnt()];
		for(int i=0;i<reportFWData.getReArrangedColList().size();i++){
			drTokens[i] = valueExtractor.extractValFromSourceUsingReportCol(reportContentData, reportFWData.getReArrangedColList().get(i),reportFWData);
		}
	  return  drMsgFormat.format(drTokens);
	}
}
