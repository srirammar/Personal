package com.otis.report.dataiterator;

import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.otis.report.content.ReportContentData;

public class RSReportContentDataIterator implements IReportContentDataIterator{

	private ResultSet repContentAsRS = null;
	private static final Logger log = Logger.getLogger(RWSReportContentDataIterator.class);
	
	public RSReportContentDataIterator(ReportContentData repContentData){
		log.info("Inside RSReportContentDataIterator().......");
		log.info("Calling super.iterateDataNWriteRowsToFile() .....");
		this.repContentAsRS = (ResultSet) repContentData.getReportContent();	
		log.info("Exiting from RSReportContentDataIterator.......");
	}
	
	
	@Override
	public boolean hasNextRow() throws Exception{
		// TODO Auto-generated method stub
		return repContentAsRS.next();
	}

	@Override
	public Object fetchNextRowOfData() {
		// TODO Auto-generated method stub
		return this;
	}

}
