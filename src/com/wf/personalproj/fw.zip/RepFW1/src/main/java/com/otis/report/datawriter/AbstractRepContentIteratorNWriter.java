package com.otis.report.datawriter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.otis.report.content.ReportContentData;
import com.otis.report.contentbuilder.RowBuilder;
import com.otis.report.contentbuilder.RowBuilderFactory;
import com.otis.report.exception.NoDataRowsExistException;
import com.otis.report.factory.ValueExtractorFactory;
import com.otis.report.model.ReportFWData;
import com.otis.report.valueextractor.IValueExtractor;

public abstract class AbstractRepContentIteratorNWriter implements IRepContentIteratorNWriter{
	private static final Logger log = Logger.getLogger(AbstractRepContentIteratorNWriter.class);
	@Override
	public void iterateDataNWriteRowsToFile(ReportContentData reportContentData,Properties reportFWProps
									,ReportFWData reportFWData,Path outputFile) throws Exception {
		
		log.info("Inside AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile()..");
		Object nextRowOfData= null;
		String currentDataRow = "";
		int rowCount = 0;
		int dataWriteBufLen = Integer.parseInt(reportFWProps.getProperty("DATA_WRITE_BUFFER_LEN"));
		log.info("AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile() dataWriteBufLen :"+dataWriteBufLen);
		//Sriram - Enable following commented code if needed
		//int waitTimeAfterDataWrite = Integer.parseInt(reportFWProps.getProperty("WAIT_TIME_AFTER_DATA_WRITE"));
		StringBuilder dataWriteBufferBuilder = new StringBuilder("");
		int bufferBuilderCnt = 1; int noOfWrites = 0;
		RowBuilder rowBuilder = RowBuilderFactory.createRowBuilder(reportFWData.getRepFormat().getReportType());
		IValueExtractor valueExtractor = ValueExtractorFactory.createValueExtractor(reportFWData.getRepFormat().getDbName());
		final long t = System.currentTimeMillis();
		while(hasNextRow()){
			++rowCount;
			nextRowOfData = fetchNextRowOfData();
			currentDataRow = rowBuilder.prepareCurrentRow(nextRowOfData,reportFWData,valueExtractor);

			dataWriteBufferBuilder.append(currentDataRow);
			dataWriteBufferBuilder.append(System.lineSeparator());
			
			if(bufferBuilderCnt<=dataWriteBufLen){
				++bufferBuilderCnt;
			}else{
				//flush buffer to file, re-initialize buffer
				Files.write( outputFile,dataWriteBufferBuilder.toString().getBytes(),StandardOpenOption.APPEND);
				dataWriteBufferBuilder = new StringBuilder(""); ++noOfWrites; bufferBuilderCnt =1;
				//Sriram - Enable following commented code if needed
				/*log.info("DataRowsBuilderNWriter::buildAndWrihiteDataRows() Waiting for "+waitTimeAfterDataWrite+" ms after flushing buffer to output file");
				Thread.sleep(waitTimeAfterDataWrite);*/
			}
		}
		log.info("AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile() No of writes before If: "+noOfWrites);
		//flush any unwritten buffer to file
		if(bufferBuilderCnt>0 && bufferBuilderCnt<=dataWriteBufLen){
			log.info("AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile() Inside If Writing unwritten rows ");
			Files.write( outputFile,dataWriteBufferBuilder.toString().getBytes(),StandardOpenOption.APPEND);
			log.info("No of writes Inside If: "+ ++noOfWrites);
		}
		log.info(String.format("DataRowsBuilderNWriter::buildAndWriteDataRows() Time taken to write data rows in %d ms.", System.currentTimeMillis() - t));
		log.info("AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile() after completion of writing data rows out of while, bufferBuilderCnt:"+bufferBuilderCnt);
		log.info("AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile(), after completion of writing data rows, noOfWrites: "+noOfWrites);
		log.info("AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile() after completion of writing data rows out of while, rowCount:"+rowCount);
		long totalRowsWrittenToFile = (noOfWrites*dataWriteBufLen)+bufferBuilderCnt;
		log.info("AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile(), after completion of writing data rows, total rows written to file: "+totalRowsWrittenToFile);
		
		reportFWData.setRowCount(rowCount);
		if(rowCount<=0){
			throw new NoDataRowsExistException("SEVERE: There is no data in the result set to create the report.");
		}
		log.info("Exiting AbstractRepContentIteratorNWriter::iterateDataNWriteRowsToFile()....");
	}
}
