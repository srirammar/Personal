package com.otis.report.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.otis.report.model.ReportCols;
import com.otis.report.util.TableColNames;

public class ReportColsMapper implements RowMapper<ReportCols> {

	public ReportCols mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		ReportCols rCols = new ReportCols();
		rCols.setReportid(arg0.getString(TableColNames.ReportCols.ReportId));
		rCols.setName(arg0.getString(TableColNames.ReportCols.ColumnName).trim().replaceAll("\"", ""));
		rCols.setWidth(arg0.getInt(TableColNames.ReportCols.Width));
		rCols.setAlignment(arg0.getString(TableColNames.ReportCols.Alignment));
		rCols.setClazzType(arg0.getString(TableColNames.ReportCols.ColumnType));
		rCols.setFormat(arg0.getString(TableColNames.ReportCols.Format));
		rCols.setColIndex(arg0.getInt(TableColNames.ReportCols.ColIndex));
		rCols.setSourceDataFormat(arg0.getString(TableColNames.ReportCols.sourceDataFormat));
		rCols.setDefaultValue(arg0.getString(TableColNames.ReportCols.defaultValue));
		return rCols;	
	}
}	
 