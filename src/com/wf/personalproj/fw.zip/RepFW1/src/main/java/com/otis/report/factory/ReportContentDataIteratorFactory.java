package com.otis.report.factory;

import com.otis.report.content.ReportContentData;
import com.otis.report.dataiterator.IReportContentDataIterator;
import com.otis.report.dataiterator.RWSReportContentDataIterator;
import com.otis.report.dataiterator.RSReportContentDataIterator;

public class ReportContentDataIteratorFactory {
	public static IReportContentDataIterator createRepContentDataIterator(String sourceOfData,ReportContentData repContentData){
		return sourceOfData.equalsIgnoreCase("RWS")?new RWSReportContentDataIterator(repContentData)
				:new RSReportContentDataIterator(repContentData);
	}
}
