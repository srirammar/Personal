package com.otis.report.contentbuilder;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.otis.report.dao.impl.GenericReportDAO;
import com.otis.report.model.ReportFWData;
import com.otis.report.support.RepFormatProcessor;

public class HeaderDtlsBuilder {
	@Autowired
	private RepFormatProcessor repFormatProcessor;
	private static final Logger log = Logger.getLogger(HeaderDtlsBuilder.class);
	public String buildHeaderContent(ReportFWData reportFWData
					,GenericReportDAO genericDao)
			throws Exception{
	
		log.info("Inside FooterDtlsBuilder::buildHeaderContent()..");
		
		String headerFormat = reportFWData.getRepFormat().getHeader();
		String sqlsOrDataValues = reportFWData.getRepSql().getHeaderValuesOrSqls();
		
		StringBuilder headerContent = repFormatProcessor.processFormattedMsg(headerFormat,reportFWData
				,sqlsOrDataValues,"header",genericDao);
		
		log.info("Inside FooterDtlsBuilder::buildHeaderContent():"+headerContent);
		
		if(headerContent.length()>0){
			headerContent.append(System.lineSeparator());
		}
		if(!StringUtils.isEmpty(reportFWData.getRepFormat().getHeaderfieldvalues()) 
				&& !reportFWData.isExcelFile()){
			log.info("Inside FooterDtlsBuilder::buildHeaderContent(): Non empty headerfieldvalues and non-excel file");
			headerContent.append(reportFWData.getRepFormat().getHeaderfieldvalues());
			headerContent.append(System.lineSeparator());
		}
		return headerContent.toString();
	}
}
