package com.otis.report.contentbuilder;

public class RowBuilderFactory {
	public static RowBuilder createRowBuilder(String rowBuilderType){
		RowBuilder retVal = null;
		if(rowBuilderType.equalsIgnoreCase(RowBuilderTypes.CSV.toString())
				||rowBuilderType.equalsIgnoreCase(RowBuilderTypes.TXT.toString())){
			retVal = new CSVRowBuilder();
		}else if(rowBuilderType.equalsIgnoreCase(RowBuilderTypes.FLT.toString())){
			retVal = new FLTRowBuilder();
		}
		
		return retVal;
	}
}
