package com.otis.report.dao;

import java.util.List;

import com.otis.report.model.RptDynamicToken;

public interface RptDynamicTokenDAO {
	public List<RptDynamicToken> getRptDynamicTokens();
	public List<RptDynamicToken> getRptDynamicTokens(String reportId);
}
