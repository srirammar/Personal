
package com.otis.report.support;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.otis.report.dao.ReportFormatDAO;
import com.otis.report.dao.ReportColsDAO;
import com.otis.report.dao.ReportSqlDAO;
import com.otis.report.dao.RptDynamicTokenDAO;
import com.otis.report.model.ReportFWData;

public class ReportFWDataFetcher {
	@Autowired
	private ReportColsDAO repColsDAO;
	@Autowired
	private ReportFormatDAO repFormatDAO;
	@Autowired
	private ReportSqlDAO repSqlDAO;
	@Autowired
	private RptDynamicTokenDAO repDynaTokenDAO;
	@Value("#{reportFWProp}")
	private Map<String,String> reportFWProp;
	private String excelFileIndr;
	private String xtendedExcelFileIndr;
	private static final Logger log = Logger.getLogger(ReportFWDataFetcher.class);
	@Value("#{reportId2ShowNullMap}") 
	private HashMap<String,String> reportId2ShowNullMap;
	@Value("#{reportId2ShowZeroAsBlankMap}") 
	private HashMap<String,String> reportId2ShowZeroAsBlankMap;
	@Value("#{reportId2ShowNullAsBlankMap}") 
	private HashMap<String,String> reportId2ShowNullAsBlankMap;
	
	public ReportFWData getReportFWData(String reportId) throws Exception{
		log.info("ReportFWDataFetcher::getReportFWData() reportId"+reportId);
		ReportFWData repFWData = new ReportFWData();
		repFWData.getRepColumnList().addAll(repColsDAO.getReportCols(reportId));
		repFWData.getRepDynTokenList().addAll(repDynaTokenDAO.getRptDynamicTokens(reportId));
		repFWData.setRepFormat(repFormatDAO.getReportFormat(reportId));
		repFWData.setRepSql(repSqlDAO.getReportSql(reportId));
		
		if(repFWData.getRepFormat()==null || repFWData.getRepSql()==null){
			throw new Exception("ReportFormat or ReportSql is missing");
		}
		repFWData.setReportId2ShowNullMap(reportId2ShowNullMap);
		repFWData.setReportId2ShowZeroAsBlankMap(reportId2ShowZeroAsBlankMap);
		repFWData.setReportId2ShowNullAsBlankMap(reportId2ShowNullAsBlankMap);
		setHeaderFieldValStrList(repFWData);	
		setReArrangedRepColList(repFWData);
		setIsExcelFile(repFWData);
		log.info("Exiting from ReportFWDataFetcher::getReportFWData() ....");
		return repFWData;
	}
	
	private void setHeaderFieldValStrList(ReportFWData reportFWData){
		log.info("Inside ReportFWDataFetcher::setHeaderFieldValStrList() ....");
		StringTokenizer st = new StringTokenizer(reportFWData.getRepFormat().getHeaderfieldvalues(),
				reportFWProp.get("Possible_Delimiters"));
		while(st.hasMoreTokens()){
			reportFWData.getHeaderFieldValStrList().add(st.nextToken());
		}
		log.info("Exiting from ReportFWDataFetcher::setHeaderFieldValStrList() ....");
	}
	
	private void setReArrangedRepColList(ReportFWData reportFWData){
		log.info("Inside ReportFWDataFetcher::setReArrangedRepColList() ....");
		boolean rearrangeCols = StringUtils.isNotEmpty(reportFWData.getRepFormat().getHeaderfieldvalues());
		if(rearrangeCols){
			log.info("ReportFWDataFetcher::setReArrangedRepColList() rearrangeCols is true ....");
			for(String headerFieldVal: reportFWData.getHeaderFieldValStrList()){
				headerFieldVal = headerFieldVal.replaceAll(" ", "").toLowerCase();
				for(int i=0;i<reportFWData.getRepColumnList().size();i++){
						String colName = reportFWData.getRepColumnList().get(i).getName().replaceAll(" ", "").toLowerCase();
						if(headerFieldVal.equals(colName)|| colName.equals(headerFieldVal)){
							reportFWData.getReArrangedColList().add(reportFWData.getRepColumnList().get(i));
							break;
						}
				}
			}
		}else{
			reportFWData.getReArrangedColList().addAll(reportFWData.getRepColumnList());
			reportFWData.getReArrangedColList().sort(new RepColsComparator());
		}
		log.info("Exiting from ReportFWDataFetcher::setReArrangedRepColList() ....");
	}
	
	private void setIsExcelFile(ReportFWData reportFWData){
		log.info("Inside ReportFWDataFetcher::setIsExcelFile() ....");
		String opFileName = reportFWData.getRepFormat().getOutputFile();
		if(opFileName!=null){
			opFileName = opFileName.toLowerCase();
		}
		if(StringUtils.endsWithAny(opFileName,new String[]{excelFileIndr,xtendedExcelFileIndr})){
			log.info("Inside ReportFWDataFetcher::setIsExcelFile() , setting it to true....");
			reportFWData.setExcelFile(true);
		}
		if(StringUtils.endsWith(opFileName,xtendedExcelFileIndr)){
			log.info("Inside ReportFWDataFetcher::setIsExcelFile() , setting XlsxFile  to true....");
			reportFWData.setXlsxFile(true);
		}		
	}
	public void setExcelFileIndr(String excelFileIndr) {
		this.excelFileIndr = excelFileIndr;
	}

	public void setXtendedExcelFileIndr(String xtendedExcelFileIndr) {
		this.xtendedExcelFileIndr = xtendedExcelFileIndr;
	}
}
