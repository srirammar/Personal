package com.otis.report;

public interface ReportGenerator {
	
	public boolean displayReport(String reportId,String cmdLineRptDynaTokens) throws Exception;
}
