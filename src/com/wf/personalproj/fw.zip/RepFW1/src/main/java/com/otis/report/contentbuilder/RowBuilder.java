package com.otis.report.contentbuilder;

import com.otis.report.model.ReportFWData;
import com.otis.report.valueextractor.IValueExtractor;

public interface RowBuilder {
	public String prepareCurrentRow(Object reportContentData,ReportFWData reportFWData
			,IValueExtractor valueExtractor) throws Exception;	
}
