package com.otis.report.content;

/**
 * Holds the report content which would be presented on the screen
 * @author U517939
 *
 */
public class ReportContentData{
	public Object getReportContent() {
		return reportContent;
	}

	public void setReportContent(Object reportContent) {
		this.reportContent = reportContent;
	}

	private Object reportContent;
	
	public boolean isReportContentDataNull(){
		return (reportContent==null);
	}
	
	public boolean isReportContentDataNotNull(){
		return !isReportContentDataNull();
	}
}
