package com.otis.report.factory;

import com.otis.report.datawriter.IRepContentIteratorNWriter;
import com.otis.report.datawriter.RSRepContentIteratorNWriter;
import com.otis.report.datawriter.RWSRepContentIteratorNWriter;

public class RepContentIteratorNWriterFactory {
	public static IRepContentIteratorNWriter createRepContentIteratorNWriter(String sourceOfData){
		return sourceOfData.equalsIgnoreCase("RWS")?new RWSRepContentIteratorNWriter():
			new RSRepContentIteratorNWriter();
	}
}
