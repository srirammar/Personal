package com.otis.report.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.otis.report.model.ReportSql;
import com.otis.report.util.TableColNames;

public class ReportSqlMapper implements RowMapper<ReportSql> {

	public ReportSql mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		ReportSql rSql = new ReportSql();
		rSql.setReportid(arg0.getString(TableColNames.ReportSql.ReportId));
		rSql.setHeaderValuesOrSqls(arg0.getString(TableColNames.ReportSql.HeaderValuesOrSqls));
		rSql.setFooterValuesOrSqls(arg0.getString(TableColNames.ReportSql.FooterValuesOrSqls));
		rSql.setDataValuesOrSqls(arg0.getString(TableColNames.ReportSql.DataValuesOrSqls));

		return rSql;
	}

	

}
