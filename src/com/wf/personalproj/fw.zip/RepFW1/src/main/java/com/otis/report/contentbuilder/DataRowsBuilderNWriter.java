package com.otis.report.contentbuilder;

import java.nio.file.Path;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.otis.report.content.ReportContentData;
import com.otis.report.datawriter.IRepContentIteratorNWriter;
import com.otis.report.factory.RepContentIteratorNWriterFactory;
import com.otis.report.model.ReportFWData;
import com.otis.report.model.ReportFormat;
import com.otis.report.util.FormatValidator;
import com.otis.report.util.ReportingFWUtil;

public class DataRowsBuilderNWriter {
	private static final Logger log = Logger.getLogger(DataRowsBuilderNWriter.class);
	private String  tokenOpenIndr;
	private String  tokenCloseIndr;
	private String invalidFormatMsg;
	private String notEnoughTokensMsg;
	@Resource(name = "reportFWProps")
	private Properties reportFWProps;
	
	public void setFixedLengFileType(String fixedLengFileType) {
		this.fixedLengFileType = fixedLengFileType;
	}

	public void setAbstractBodyDefIndr(String abstractBodyDefIndr) {
		this.abstractBodyDefIndr = abstractBodyDefIndr;
	}

	private String fixedLengFileType;
	private String abstractBodyDefIndr;
	
	public void setTokenOpenIndr(String tokenOpenIndr) {
		this.tokenOpenIndr = tokenOpenIndr;
	}


	public void setTokenCloseIndr(String tokenCloseIndr) {
		this.tokenCloseIndr = tokenCloseIndr;
	}


	public void setInvalidFormatMsg(String invalidFormatMsg) {
		this.invalidFormatMsg = invalidFormatMsg;
	}


	public void setNotEnoughTokensMsg(String notEnoughTokensMsg) {
		this.notEnoughTokensMsg = notEnoughTokensMsg;
	}

	public void buildAndWriteDataRows(ReportFWData reportFWData,
			ReportContentData reportContentData,Path outputFile) throws Exception{
		
		log.info("Inside DataRowsBuilderNWriter::buildAndWriteDataRows()..");

		if(isAbstractDataRowFormatDef(reportFWData.getRepFormat())){
			updateDataRowFormatInRepFormat(reportFWData.getRepFormat());
		}
		String dataRowFormat = reportFWData.getRepFormat().getBody();
	
		if(!FormatValidator.validateFormat(dataRowFormat,tokenOpenIndr,tokenCloseIndr)){
			throw new Exception(invalidFormatMsg);
		}
		
		int tokenCnt = StringUtils.countMatches(dataRowFormat, tokenOpenIndr);
		reportFWData.setDataRowTokenCnt(tokenCnt);
		log.info("DataRowsBuilderNWriter::buildAndWriteDataRows() tokenCnt:"+tokenCnt);
		
		if(tokenCnt!=reportFWData.getRepColumnList().size()){
			throw new Exception(notEnoughTokensMsg);
		}
		
		try{
			 IRepContentIteratorNWriter repContentItNWriter = RepContentIteratorNWriterFactory.createRepContentIteratorNWriter
					 					(reportFWData.getRepFormat().getDbName());
			 repContentItNWriter.iterateDataNWriteRowsToFile(reportContentData, reportFWProps, reportFWData, outputFile);
		}catch(Exception ex){
			log.info("Exception occurred while trying to fetch data rows from result set.");
			throw ex;
		}
		log.info("Exiting from DataRowsBuilderNWriter::buildAndWriteDataRows()..");
	}
	   
   private boolean isAbstractDataRowFormatDef(ReportFormat repFormat){
	   log.info("Inside DataRowsBuilderNWriter::buildAndWriteDataRows()..");
	   if(repFormat.getReportType()!=null && repFormat.getReportType().equalsIgnoreCase(fixedLengFileType)){
		   if(repFormat.getBody().contains(abstractBodyDefIndr)) return true;
	   }
	   log.info("Returning false from DataRowsBuilderNWriter::buildAndWriteDataRows()..");
	   return false;
   }
   
   private void updateDataRowFormatInRepFormat(ReportFormat repFormat){
	  log.info("Inside DataRowsBuilderNWriter::updateDataRowFormatInRepFormat()..");
	  String body = repFormat.getBody().replaceAll(" ", "");
	  String str =  StringUtils.substringAfterLast( body, (abstractBodyDefIndr+tokenOpenIndr));
	  str= str.replace(tokenCloseIndr, ""); 
	  repFormat.setBody(ReportingFWUtil.getMessageFormatTokensStr(Integer.parseInt(str),tokenOpenIndr,tokenCloseIndr));
	  log.info("Exiting from DataRowsBuilderNWriter::updateDataRowFormatInRepFormat()..");
   }
}
 