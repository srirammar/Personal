package com.otis.report.valueextractor;

import com.otis.report.model.ReportCols;
import com.otis.report.model.ReportFWData;

public interface IValueExtractor {
	public String extractValFromSourceUsingReportCol(Object currentRowData
			,ReportCols repCols,ReportFWData reportFWData) throws Exception;
/*	public double extracDoubleValFromSourceUsingReportCol(Object currentRowData
			,ReportCols repCols) throws Exception;
	public int extractIntValFromSourceUsingReportCol(Object currentRowData
			,ReportCols repCols) throws Exception;
	public Date extractDateValFromSourceUsingReportCol(Object currentRowData
			,ReportCols repCols) throws Exception;
	public Calendar extractTSValFromSourceUsingReportCol(Object currentRowData
			,ReportCols repCols) throws Exception;*/
}
