package com.otis.report.contentbuilder;

import com.otis.report.model.ReportFWData;
import com.otis.report.valueextractor.IValueExtractor;

public class FLTRowBuilder implements RowBuilder{
	@Override
	public String prepareCurrentRow(Object reportContentData, ReportFWData reportFWData,IValueExtractor valueExtractor) throws Exception {
		// TODO Auto-generated method stub
		StringBuilder currentRow = new StringBuilder("");
		for(int i=0;i<reportFWData.getReArrangedColList().size();i++){
			currentRow.append(valueExtractor.extractValFromSourceUsingReportCol(reportContentData, reportFWData.getReArrangedColList().get(i),reportFWData));
		}
		return currentRow.toString();
	}

}
